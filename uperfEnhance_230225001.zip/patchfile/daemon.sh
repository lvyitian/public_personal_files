#!/system/bin/sh
execute=${0%/*}
# uperfEnhance daemon service
grep_prop() {
    REGEX="s/^$1=//p"
    shift
    FILES="$@"
    [ -z "$FILES" ] && FILES=/system/build.prop
    cat $FILES 2>/dev/null | dos2unix | sed -n "$REGEX" | head -n 1
}
wait_until_login() {
    while [ "$(getprop sys.boot_completed)" != "1" ]; do
        sleep 1
    done
    while [ ! -d "/sdcard/Android" ]; do
        sleep 1
    done
}
wkdsp() {
    echo "id=U-executor_info" >$execute/module.prop.temp
    echo "name=.Uperf the Enhance" >>$execute/module.prop.temp
    echo "version=$(grep_prop version $execute/module.prop 2>/dev/null)" >>$execute/module.prop.temp
    if [ "$2" != "" ]; then
        echo "versionCode=$2" >>$execute/module.prop.temp
    else
        echo "versionCode=$(grep_prop versionCode $execute/module.prop 2>/dev/null)" >>$execute/module.prop.temp
    fi
    echo "author=world.execute(darker); 酷安@darker_fun_" >>$execute/module.prop.temp
    echo "description=[$1] uperf补丁，解锁核心温度并控制 Repo:https://www.coolapk.com/feed/40483786" >>$execute/module.prop.temp
    echo "minMagisk=24300" >>$execute/module.prop.temp
    echo "updateJson=https://d.htcoz.com/executor_micro/update.json" >>$execute/module.prop.temp
    mv $execute/module.prop.temp $execute/module.prop
}
wait_until_login
    if [ -f "/data/adb/modules/uperf/bin/uperfEnhance_main" ]; then
        if [ "$(/data/adb/magisk/busybox ps -ef | grep 'uperf' | grep -v 'grep' | grep -v 'uperfEnhance' | awk '{print $4}' | grep 'uperf')" == "" ]; then
            wkdsp "🤯 uperf没有启动哦，模块本体在uperf里哦 你需要先打开uperf哦~"
            exit 0
        fi
    else
        wkdsp "⚠️ Uperf已更新或卸载，请先安装uperf或者安装uperfEnhance" "1"
        exit 0
    fi
    sleep 60s
    while true; do
         if [[ "$(/data/adb/magisk/busybox ps -ef | grep 'uperfEnhance' | grep -v 'grep' | awk '{print $5}' | grep '/data/adb/modules/uperf/bin/uperfEnhance_main')" == "" ]] && [[ ! -f /data/adb/modules/uperf/update ]] && [[ ! -f $execute/flag_stop ]]; then
            wkdsp "☠️ 不知道为什么死掉了喵~。先去看看log，然后尝试将selinux关闭后重启或重刷" "1"
         fi
        sleep 300s
    done
