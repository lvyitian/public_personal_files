#!/system/bin/sh
BASEDIR="$(dirname $(readlink -f "$0"))"
. $BASEDIR/pathinfo.sh
. $BASEDIR/libcommon.sh
. $BASEDIR/libsysinfo.sh
action="$1"
    if [ "$top_app" != "standby" ] && [ "$top_app" != "" ]; then
        echo "$top_app anisotropic_disable 1" >/sys/kernel/ged/gpu_tuner/custom_hint_set
    fi
    case "$action" in
        "powersave" | "balance" |"performance" |  "fast" | "auto" ) echo "$1" >"$USER_PATH"/cur_powermode.txt ;;
        "init") echo "auto" >"$USER_PATH/cur_powermode.txt" ;;
        "pedestal")
        if [ "$(grep -E "pedestal" < "$USER_PATH"/uperf.json)" != "" ];then
            echo "pedestal" >"$USER_PATH"/cur_powermode.txt
        else
            echo "performance" >"$USER_PATH"/cur_powermode.txt
        fi
        ;;
        *)
        echo "Failed to apply unknown action '$1'. Reset current mode to 'balance'."
        echo "auto" >"$USER_PATH/cur_powermode.txt"
        ;;
    esac