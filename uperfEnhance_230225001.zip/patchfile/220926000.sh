#!/system/bin/sh
# by hamjin, coolapk@HamJTY
BASEDIR="$(dirname "$(readlink -f "$0")")"
. "$BASEDIR"/pathinfo.sh
. "$BASEDIR"/libcommon.sh
. "$BASEDIR"/libpowercfg.sh
. "$BASEDIR"/libcgroup.sh
. "$BASEDIR"/libsysinfo.sh
hide_value() {
    umount "$1" 2>/dev/null
        if [ ! -f "/cache/$1" ]; then
            mkdir -p "/cache/$1"
            rm -r "/cache/$1"
            cat "$1" >"/cache/$1"
        fi
        if [ "$2" != "" ]; then
            lock_val "$2" "$1"
        fi
    mount "/cache/$1" "$1"
}
task_turbo() {
    PRE_PID=$(cat /cache/task_turbo_pid)
    for i in $PRE_PID; do
        echo "$i" >>/sys/module/task_turbo/parameters/unset_turbo_pid
    done
    echo "$top_app" >/cache/cur_top_app
    echo "" >/cache/task_turbo_pid
    PID=$(pgrep "$top_app")
    for i in $PID; do
        echo "$i" >>/cache/task_turbo_pid
        echo "$i" >>/sys/module/task_turbo/parameters/turbo_pid
    done
}
lock_val "0" /proc/sys/kernel/sched_big_task_rotation
lock_val "0" /proc/perfmgr/boost_ctrl/eas_ctrl/sched_big_task_rotation
lock_val "0" "/sys/module/mtk_fpsgo/parameters/boost_affinity*"
lock_val "0" "/sys/module/fbt_cpu/parameters/boost_affinity*"
lock_val "9999000" "/sys/kernel/fpsgo/fbt/limit_*"
lock_val "0" /sys/kernel/fpsgo/fbt/switch_idleprefer
lock_val "0" /sys/kernel/fpsgo/minitop/enable
lock_val "1" /proc/perfmgr/syslimiter/syslimiter_force_disable
lock_val "0" /sys/module/mtk_core_ctl/parameters/policy_enable
lock_val "120" /sys/kernel/fpsgo/fbt/thrm_temp_th
lock_val "1" /sys/kernel/fpsgo/fbt/thrm_limit_cpu
lock_val "2" /sys/kernel/fpsgo/fbt/thrm_sub_cpu
IS_MIUI=$(getprop ro.miui.ui.version.code)
    if [ "$(getprop ro.system.build.version.sdk)" -ge 33 ]; then
        if [ -d "/proc/gpufreqv2" ] && [ "$IS_MIUI" -gt 12 ]; then
            echo "enable fpsgo"
            lock_val "disable" /proc/gpufreqv2/aging_mode
        else
            echo "stop fpsgo"
            lock_val "0" /sys/kernel/fpsgo/common/fpsgo_enable
            lock_val "0" /sys/kernel/fpsgo/common/force_onoff
        fi
    elif [ -d "/proc/gpufreqv2" ]; then
        echo "detected new platform"
        if [ "$IS_MIUI" -gt 12 ]; then
            echo "enable fpsgo"
        else
            echo "stop fpsgo"
            lock_val "0" /sys/kernel/fpsgo/common/fpsgo_enable
            lock_val "0" /sys/kernel/fpsgo/common/force_onoff
        fi
        LIST=$(ls -1 /sys/kernel/debug/mali0/ctx)
        for i in $LIST; do
            lock_val "Y" /sys/kernel/debug/mali0/ctx/"$i"/infinite_cache
        done
        lock_val "disable" /proc/gpufreqv2/aging_mode
        lock_val "stop 1" /proc/mtk_batoc_throttling/battery_oc_protect_stop
        lock_val "cm_mgr_cpu_map_dram_enable 0" /sys/kernel/cm_mgr/dbg_cm_mgr
        lock_val "dsu_enable 1" /sys/kernel/cm_mgr/dbg_cm_mgr
    else
        echo "detected old platform"
        lock_val "0" /sys/module/cache_ctl/parameters/enable
        echo "stop fpsgo"
        lock_val "0" /sys/kernel/fpsgo/common/fpsgo_enable
        lock_val "0" /sys/kernel/fpsgo/common/force_onoff
        lock_val "0" /proc/gpufreq/gpufreq_aging_enable
        lock /sys/devices/system/cpu/sched/set_sched_isolation
        for i in 0 1 2 3 4 5 6 7 8 9; do
            lock_val "0" "$CPU"/cpu$i/sched_load_boost
            lock_val "$i" /sys/devices/system/cpu/sched/set_sched_deisolation
        done
        echo "force uperf use PPM"
        lock_val "0 3200000" /proc/ppm/policy/hard_userlimit_max_cpu_freq
        lock_val "0 3200000" /proc/ppm/policy/hard_userlimit_min_cpu_freq
        lock_val "1 3200000" /proc/ppm/policy/hard_userlimit_max_cpu_freq
        lock_val "1 3200000" /proc/ppm/policy/hard_userlimit_min_cpu_freq
        lock_val "2 3200000" /proc/ppm/policy/hard_userlimit_max_cpu_freq
        lock_val "2 3200000" /proc/ppm/policy/hard_userlimit_min_cpu_freq
        lock_val "0" /sys/kernel/eara_thermal/enable
        lock_val "cm_mgr_cpu_map_dram_enable 0" /proc/cm_mgr/dbg_cm_mgr
    fi
lock_val "10" /sys/class/thermal/thermal_message/sconfig
stop vendor_tcpdump
stop miuibooster
stop vendor.miperf
stop mcd_service
start mcd_service
stop fpsgo
start fpsgo
lock_val "0" /sys/kernel/fpsgo/minitop/enable