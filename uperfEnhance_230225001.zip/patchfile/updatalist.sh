#!/system/bin/sh
uperf="/data/adb/modules/uperf"
execute="/data/adb/modules/U-executor_info"
cp $execute/newver/service.sh $uperf/service.sh 2>/dev/null
cp $execute/newver/bin/uperfEnhance_main $uperf/bin/uperfEnhance_main 2>/dev/null
if [ -f "/proc/mtktz/mtktscpu" ]; then
    cp $execute/newver/patchfile/cfg_enhance.prop /data/media/0/Android/darker/uperfEnhance 2>/dev/null
else
    rm -rf /data/media/0/Android/darker/uperfEnhance/cfg_enhance.prop
fi
cp $execute/newver/patchfile/daemon.sh /data/adb/modules/U-executor_info/service.sh 2>/dev/null
cp $execute/newver/module.prop $execute/module.prop