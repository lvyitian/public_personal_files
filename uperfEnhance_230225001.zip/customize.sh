set_perm_recursive  $MODPATH  0  0  0775  0775
lock_val() {
    chown root:root "$2" 2>/dev/null
    chmod 0666 "$p" 2>/dev/null
    echo "$1" > "$p"  2>/dev/null
    chmod 0444 "$p" 2>/dev/null
}
grep_prop() {
    REGEX="s/^$1=//p"
    shift
    FILES="$@"
    [ -z "$FILES" ] && FILES='/system/build.prop'
    cat $FILES 2>/dev/null | dos2unix | sed -n "$REGEX" | head -n 1
}
fuckhamjin() {
    if [ "$1" != "md5" ]; then
        for i in $2; do
            if [ $(grep_prop versionCode $uperf/module.prop) == $i ]; then
                cp $MODPATH/patchfile/$i.sh $uperf/script/$3
            fi
        done
    else
        if [ "$uperf" == "/data/adb/modules/uperf" ]; then
            md5="$(md5sum -c $MODPATH/patchfile/$2.md5)"
        else
            md5="$(md5sum -c $MODPATH/patchfile/$2.up.md5)"
        fi
        if [ "$md5" == "$uperf/script/$2: OK" ]; then
            cp $MODPATH/patchfile/$2 $uperf/script/$2
        fi
    fi
}
remake() {
    killall -9 MTK-Enhance_main
    pkill MTK-Enhance_main
    killall -9 uperfEnhance_main
    pkill uperfEnhance_main
    mv $uperf/module.prop.old $uperf/module.prop
    mv $uperf/servicelast.sh $uperf/service.sh
    mv $uperf/post-fs-data.sh.old $uperf/post-fs-data.sh
    mv $uperf/system.prop.old $uperf/system.prop
    mv $uperf/uninstall.sh.old $uperf/uninstall.sh
    rm -rf /data/media/0/Android/MTK-Enhance*
    rm -rf $uperf/MTK-Enhance_main*
    rm -rf $uperf/uperfEnhance_main
    rm -rf /data/media/0/Android/darker/uperfEnhance/debug.log
}
volume_keytest() {
echo "
- *******************************"
echo '                        __ _____       _'
echo '  _   _ _ __  ___ _ __ / _| ____._ __ | |__   __ _ _ __   ___ ___'
echo ' | | | | "_ \/ _ \ "__| |_|  _| | "_ \| "_ \ / _` | "_ \ / __/ _ \'
echo ' | |_| | |_)|| __/ |  |  _| |___| | | | | | | (_| | | | | (_|  __/'
echo '  \__,_| .__/\___|_|  |_| |_____|_| |_|_| |_|\__,_|_| |_|\___\___|'
echo '       |_|'
echo "
- *******************************

- 𝕌𝕡𝕖𝕣𝕗𝔼𝕟𝕙𝕒𝕟𝕔𝕖 —— uperf增强补丁：解锁核心温度并控制

- 版本: $(grep_prop versionCode $MODPATH/module.prop)
- 作者：world.execute(darker); 酷安@darker_fun_
- *******************************
- 有可能导致开机开机卡屏、无限重启、开机完成后经常自动重启等风险- - - - - -
- 甚至可能造成设备损坏等不可逆损失!！- - - - - -
- 对造成的损失作者将不负责。- - - - - -
- 需要装好有效救砖模块。- - - - - -
- 或者准备可以有效解密data分区的recovery- - - - - -
- 如想取消安装，请在之后选择第二项卸载- - - - - -
- *******************************"
[[ -f "/proc/mtktz/mtktscpu" ]] && echo "- 用户温控检测配置调整文件，可以在/sdcard/Android/darker/uperfEnhance/cfg_enhance.prop里调整温度检测的阈值。"
echo "
- 运行log位置: /sdcard/Android/darker/uperfEnhance/uperfEnhance.log
- *******************************
--- 音量键测试 ---（请不要点击屏幕）

  请按音量+或-键"
  (/system/bin/getevent -lc 1 2>&1 | /system/bin/grep VOLUME | /system/bin/grep " DOWN" > $TMPDIR/events) || return 1
  return 0
}
volume_choose() {
    while true; do
        /system/bin/getevent -lc 1 2>&1 | /system/bin/grep VOLUME | /system/bin/grep " DOWN" > $TMPDIR/events
        if (`cat $TMPDIR/events 2>/dev/null | /system/bin/grep VOLUME >/dev/null`); then
            break
        fi
    done
    if (`cat $TMPDIR/events 2>/dev/null | /system/bin/grep VOLUMEUP >/dev/null`); then
        return 1
    else
        return 0
    fi
}
volume_key_test() {
    if volume_keytest; then
        KEYTEST=volume_choose
        echo "- 音量键测试完成
        
"
    else
        KEYTEST=false
        rm -rf /data/adb/modules/U-executor_info
        abort "

 ！错误：没有检测到音量键选择
 
- 已回复原版uperf并取消安装
"
    fi
    sleep 0.5
}
chk() {
    [[ "$(/data/adb/magisk/busybox ps -ef | grep 'uperf' | grep -v 'grep' | grep -v 'uperfEnhance' | awk '{print $4}' | grep 'uperf')" == "" ]] && abort "

- 没有检测到uperf运行！你需要安装或者打开uperf并确保uperf正常运行再进行安装。

"
}
ins() {
    echo "
--- 请选择是否安装模块 ---

  音量+键 = 安装,安装𝕌𝕡𝕖𝕣𝕗𝔼𝕟𝕙𝕒𝕟𝕔𝕖。
  
  音量-键 = 卸载,回复原版uperf。
"
    sleep 0.5s
    if "$KEYTEST"; then
        rm -rf /data/adb/modules/U-executor_info
        abort "
- 已回复原版uperf功能。
"
    else
        if [ -f "$uperf/service.sh" ]; then
            mv $uperf/service.sh $uperf/servicelast.sh
        else
            echo "" $uperf/servicelast.sh
        fi
        echo "
- 正在安装。。。
"
        rm -rf /data/media/0/Android/MTK-Enhance
        mkdir -p /data/media/0/Android/darker/uperfEnhance
        mkdir /data/adb/modules/U-executor_info/
        cp $MODPATH/service.sh $uperf/service.sh
        cp $MODPATH/bin/uperfEnhance_main $uperf/bin/uperfEnhance_main
        cp $MODPATH/bin/curl $uperf/bin/curl
        if [ -f "/proc/mtktz/mtktscpu" ]; then
            cp $MODPATH/patchfile/cfg_enhance.prop /data/media/0/Android/darker/uperfEnhance/cfg_enhance.prop
        else
            rm -rf /data/media/0/Android/darker/uperfEnhance/cfg_enhance.prop
        fi
        cp $MODPATH/module.prop /data/adb/modules/U-executor_info/module.prop
        cp $MODPATH/patchfile/daemon.sh /data/adb/modules/U-executor_info/service.sh
        fuckhamjin '220926000' mtk_special.sh
        fuckhamjin md5 powercfg_main.sh
        rm -rf /data/adb/modules*/uperf_enhance*
        rm -rf $TMPDIR
        rm -rf /data/adb/modules_update/U-executor_info
        echo "- Executing me..."
        mv /data/media/0/Android/darker/uperfEnhance/uperfEnhance.log /data/media/0/Android/darker/uperfEnhance/uperfEnhance.last.log
        nohup $uperf/bin/uperfEnhance_main >/data/media/0/Android/darker/uperfEnhance/uperfEnhance.log &
        echo "- 安装完成！"
        exit 0
    fi
}
uperf=/data/adb/modules/uperf
MODAUTHOR="$(grep_prop author $TMPDIR/module.prop)" && [ "$MODAUTHOR" != 'world.execute(darker); 酷安@darker_fun_' ] && abort "



- NMSL


"
    if [ -f "$uperf/update" ]; then
        uperf=/data/adb/modules_update/uperf
            remake
            volume_key_test
            ins
    else
        chk
        remake
        volume_key_test
        ins
    fi
