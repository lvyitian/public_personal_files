#!/system/bin/sh
MODDIR=${0%/*}
wait_until_login() {
    while [ "$(getprop sys.boot_completed)" != "1" ]; do
        sleep 5
    done
    while [ ! -d "/sdcard/Android" ]; do
        sleep 5
    done
}
sh $MODDIR/servicelast.sh &
wait_until_login
rm -rf /data/adb/modules*/uperf_enhance*
mkdir /data/media/0/Android/darker/uperfEnhance
rm -rf /data/media/0/Android/MTK-Enhance*
mv /data/media/0/Android/darker/uperfEnhance/uperfEnhance.log /data/media/0/Android/darker/uperfEnhance/uperfEnhance.lastboot.log
nohup $MODDIR/bin/uperfEnhance_main >/data/media/0/Android/darker/uperfEnhance/uperfEnhance.log &
