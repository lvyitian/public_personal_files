package net.dev.Listeners;

import net.dev.API.Minecraft.*;
import net.dev.Database.*;
import net.dev.*;
import net.dev.Utils.DatabaseUtils.*;
import org.bukkit.*;
import org.bukkit.configuration.*;
import org.bukkit.entity.*;
import org.bukkit.event.*;
import org.bukkit.event.player.*;

import java.util.concurrent.atomic.*;

import static net.dev.Utils.PlayerUtils.FlyUtils.FlyUtils.*;
import static net.dev.Utils.StringUtils.StringUtils.*;

public class PlayerJoinListener implements Listener {
    @EventHandler (priority = EventPriority.HIGHEST)
    public void onPlayerJoin(PlayerJoinEvent event) throws Throwable {
        Player p = event.getPlayer();
        String fly= LoadDatabase.db.dbSelectFirst("CommandsEnable","fly",new KeyValue(){{ this.add("uuid",p.getUniqueId().toString()); }});
        if(GrewEssentials.getInstance().Message.getBoolean("Fly.Fly_Allow")){
            if(fly!=null && fly.equals("1")){
                if(GrewEssentials.getInstance().Message.getBoolean("Fly.Fly_Permission")){
                    if (p.hasPermission(GrewEssentials.getInstance().Config.getString("Permissions.Fly.Self")) || p.hasPermission(GrewEssentials.getInstance().Config.getString("Permissions.All"))){
                        enableFlight(p);
                    }
                }else{
                    enableFlight(p);
                }
            }
        }
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent event) throws Throwable{
        Player p = event.getPlayer();
        String worldName = p.getWorld().getName();
        if(GrewEssentials.getInstance().bossbar.getBoolean("BossBar"))
        {
            if(GrewEssentials.getInstance().bossbar.get("per-world")==null || isNullOrEmptyWithTrim(((MemorySection)GrewEssentials.getInstance().bossbar.get("per-world")).getString(worldName,"")) || GrewEssentials.getInstance().bossbar.get("bars."+((MemorySection)GrewEssentials.getInstance().bossbar.get("per-world")).getString(worldName,""),null)==null)
            {
                Object b=GrewEssentials.getInstance().bossbar.get("bars."+GrewEssentials.getInstance().bossbar.getString("default-bars",""),null);
                if(b!=null)
                    DedicatedMethods.startPlayBossbar(p,(MemorySection)b);
            }else{
                MemorySection ms=(MemorySection)GrewEssentials.getInstance().bossbar.get("per-world");
                String bar=ms.getString(worldName);
                MemorySection ms2=(MemorySection) GrewEssentials.getInstance().bossbar.get("bars."+bar);
                BossBar.getIndexesAtomicByPlayer(p, i->{
                    for(AtomicInteger a : i)
                    {
                        Bukkit.getScheduler().runTask(GrewEssentials.getInstance(),()->BossBar.removeBossbar(a));
                    }
                });
                DedicatedMethods.startPlayBossbar(p,ms2);
            }
        }
    }
}
