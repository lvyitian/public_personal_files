package net.dev.Listeners;

import net.dev.API.Minecraft.*;
import org.bukkit.entity.*;
import org.bukkit.event.*;
import org.bukkit.event.player.*;

import java.util.*;
import java.util.concurrent.atomic.*;

public class PlayerQuitListener implements Listener {
    @EventHandler(priority=EventPriority.MONITOR)
    public void onPlayerQuitRealTime(PlayerQuitEvent e)
    {
        BossBar.getIndexesAtomicByPlayer(e.getPlayer(),i->{
            for(AtomicInteger i2 : i)
            {
                BossBar.removeBossbar(i2);
            }
        });
    }
    @EventHandler
    public void onPlayerQuit(PlayerQuitEvent event) {
        Player p = event.getPlayer();
        UUID u =p.getUniqueId();

    }
}
