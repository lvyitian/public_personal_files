package net.dev.Utils.CommandUtils;

import org.bukkit.command.*;

import java.util.*;

public interface CommandWithCompleter extends CommandExecutor,TabCompleter {
}
