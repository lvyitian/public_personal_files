package net.dev.Utils.CommandUtils;

import org.bukkit.*;

import java.util.*;

public class CommandUtil {

    public static Vector<String> commandListToCommandNameList(Vector<IChildCommand> v)
    {
        Vector<String> ret=new Vector<>();
        for(IChildCommand i : v)
        {
            ret.add(i.getClass().getSimpleName().toLowerCase());
        }
        return ret;
    }
    public static IChildCommand getCommand(Vector<IChildCommand> l,String cmd)
    {
        for(IChildCommand i : l)
        {
            if(i.getClass().getSimpleName().equalsIgnoreCase(cmd))
                return i;
        }
        return null;
    }
    public static class ArgumentUtil{
        public static boolean isOnlinePlayerExists(UUID uuid)
        {
            return Bukkit.getPlayer(uuid)!=null;
        }
        public static boolean isOnlinePlayerExists(String name)
        {
            return Bukkit.getPlayer(name)!=null;
        }
        public static boolean isDouble(String s)
        {
            try {
                return !Double.valueOf(s).equals(Double.NaN);
            }catch(Throwable e) {return false;}
        }
        public static boolean isLong(String s)
        {
            try {
                Long.valueOf(s);
                return true;
            }catch(Throwable e) {return false;}
        }
        public static boolean isInteger(String s)
        {
            try {
                Integer.valueOf(s);
                return true;
            }catch(Throwable e) {return false;}
        }
        public static boolean isUUID(String s)
        {
            try {
                UUID.fromString(s);
                return true;
            }catch(Throwable e) {return false;}
        }
    }
}
