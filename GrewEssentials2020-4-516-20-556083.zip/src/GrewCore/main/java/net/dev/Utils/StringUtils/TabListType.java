package net.dev.Utils.StringUtils;

import org.bukkit.*;
import org.bukkit.entity.*;

import java.util.*;

public class TabListType {
    public static ArrayList<String> offlinePlayerListToNameList(Vector<OfflinePlayer> v)
    {
        ArrayList<String> ret=new ArrayList<>();
        for(OfflinePlayer i : v)
            ret.add(i.getName());
        return ret;
    }

    public static ArrayList<String> getOfflinePlayersNameList()
    {
        return offlinePlayerListToNameList(VectorUtil.toVector(Bukkit.getOfflinePlayers()));
    }

    public static ArrayList<String> onlinePlayerListToNameList()
    {
        ArrayList<String> ret=new ArrayList<>();
        for(Player i : Bukkit.getOnlinePlayers())
            ret.add(i.getName());
        return ret;
    }
    public static ArrayList<String> getOnlinePlayersNameList()
    {
        return onlinePlayerListToNameList();
    }

    public static Vector<String> getFileType(){
        Vector<String> ret=new Vector<>();
        ret.add("config");
        ret.add("message");
        ret.add("database");
        ret.add("log");
        ret.add("bossbar");
        return ret;
    }

}
