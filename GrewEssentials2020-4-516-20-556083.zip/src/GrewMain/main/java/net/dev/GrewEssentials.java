package net.dev;

import net.dev.API.Minecraft.*;
import net.dev.Commands.*;
import net.dev.Commands.Gamemode.*;
import net.dev.Commands.GrewEssentials.*;
import net.dev.File.*;
import net.dev.Listeners.*;
import net.dev.Utils.StringUtils.*;
import net.dev.Utils.*;
import org.bukkit.*;
import org.bukkit.plugin.java.*;

import java.util.concurrent.atomic.*;

import static net.dev.ReflectionWrapper.*;
import static net.dev.Utils.CommandUtils.RegisterCommands.*;
import static net.dev.Utils.DatabaseUtils.LoadDatabase.*;
import static net.dev.Utils.LogUtils.LogUtils.*;

public class GrewEssentials extends JavaPlugin {
    public static GrewEssentials instance;
    public static GrewEssentials getInstance() { return instance; }

    public ConfigFile Config;
    public MessageFile Message;
    public logMessageFile log;
    public BossBarFile bossbar;

    public static String version = "XX_XX_RXX";

    @Override
    public void onEnable(){
        instance = this;
        version = getVersion().substring(1);
        loadFile();
        loadDatabase(); 
        regCmds();
        regTabCms();
        regListeners();
        log();
    }
    @Override
    public void onDisable(){
        Bukkit.getOnlinePlayers().parallelStream().forEach(i->{
            BossBar.getIndexesAtomicByPlayer(i,i2->{
                for(AtomicInteger i3 : i2)
                {
                    BossBar.removeBossbar(i3);
                }
            });
        });
        Bukkit.getOnlinePlayers().forEach(i->{
            if(i.getOpenInventory() !=null && InvSeeCommand.ivs.containsKey(i.getOpenInventory()))
                i.closeInventory();
        });
        try{
            db.close();
        }catch (Throwable e){
            Utils.sendConsole(getInstance().Message.getString("DataBase.DatabaseUnLoadError"));
        }
        instance = null;
    }

    private void loadFile(){
        Message = new MessageFile(this);
        Config = new ConfigFile(this);
        log = new logMessageFile(this);
        bossbar = new BossBarFile(this);
    }

    private void regListeners(){
        Bukkit.getPluginManager().registerEvents(new PlayerJoinListener(), this);
        Bukkit.getPluginManager().registerEvents(new PlayerQuitListener(), this);
        Bukkit.getPluginManager().registerEvents(new PlayerMoveListener(), this);
        Bukkit.getPluginManager().registerEvents(new InventoryListener(),this);
    }

    private void regCmds() {
        regComWithCompleter(this.getName(),setComDesc(setComUsa(setComAlias(newPluginCommand("gamemode",new GamemodeCommand(),this),"gm"), StringUtils.translateColorCodes(getInstance().Message.getString("Gamemode.Usage").replace("$prefix",""))),StringUtils.translateColorCodes(getInstance().Message.getString("Gamemode.Usage_Explanation").replace("$prefix",""))));
        regComWithCompleter(this.getName(),setComDesc(setComUsa(setComAlias(newPluginCommand("grewessentials",new GrewEssentialsCommand(),this),"g","ghelp","grewessentialshelp"), StringUtils.translateColorCodes(getInstance().Message.getString("Help.Usage").replace("$prefix",""))),StringUtils.translateColorCodes(getInstance().Message.getString("Help.Usage_Explanation").replace("$prefix",""))));
        regComWithCompleter(this.getName(),setComDesc(setComUsa(setComAlias(newPluginCommand("grewreload",new ReloadCommand(),this),"greload"), StringUtils.translateColorCodes(getInstance().Message.getString("Reload.Usage").replace("$prefix",""))),StringUtils.translateColorCodes(getInstance().Message.getString("Reload.Usage_Explanation").replace("$prefix",""))));

        regCom(this.getName(),setComDesc(setComUsa(setComAlias(newPluginCommand("light",new LightCommand(),this),"shock"), StringUtils.translateColorCodes(getInstance().Message.getString("Light.Alone.Usage").replace("$prefix",""))),StringUtils.translateColorCodes(getInstance().Message.getString("Light.Alone.Usage_Explanation").replace("$prefix",""))));
        regCom(this.getName(),setComDesc(setComUsa(setComAlias(newPluginCommand("lighta",new LightaCommand(),this),"shocka"), StringUtils.translateColorCodes(getInstance().Message.getString("Light.All.Usage").replace("$prefix",""))),StringUtils.translateColorCodes(getInstance().Message.getString("Light.All.Usage_Explanation").replace("$prefix",""))));
        regCom(this.getName(),setComDesc(setComUsa(setComAlias(newPluginCommand("invsee",new InvSeeCommand(),this),"inv","inventory"), StringUtils.translateColorCodes(getInstance().Message.getString("InvSee.Usage").replace("$prefix",""))),StringUtils.translateColorCodes(getInstance().Message.getString("InvSee.Usage_Explanation").replace("$prefix",""))));
        regCom(this.getName(),setComDesc(setComUsa(setComAlias(newPluginCommand("sucide",new SucideCommand(),this),"自杀"), StringUtils.translateColorCodes(getInstance().Message.getString("Sucide.Usage").replace("$prefix",""))),StringUtils.translateColorCodes(getInstance().Message.getString("Sucide.Usage_Explanation").replace("$prefix",""))));
        regCom(this.getName(),setComDesc(setComUsa(setComAlias(newPluginCommand("broadcast",new BroadCastCommand(),this),"bc"), StringUtils.translateColorCodes(getInstance().Message.getString("BroadCast.Usage").replace("$prefix",""))),StringUtils.translateColorCodes(getInstance().Message.getString("BroadCast.Usage_Explanation").replace("$prefix",""))));
        regCom(this.getName(),setComDesc(setComUsa(setComAlias(newPluginCommand("announcement",new AnnouncementCommand(),this),"note"), StringUtils.translateColorCodes(getInstance().Message.getString("Announcement.Usage").replace("$prefix",""))),StringUtils.translateColorCodes(getInstance().Message.getString("Announcement.Usage_Explanation").replace("$prefix",""))));
        regCom(this.getName(),setComDesc(setComUsa(setComAlias(newPluginCommand("KickAll",new KickAllCommand(),this),"kicka"), StringUtils.translateColorCodes(getInstance().Message.getString("KickAll.Usage").replace("$prefix",""))),StringUtils.translateColorCodes(getInstance().Message.getString("KickAll.Usage_Explanation").replace("$prefix",""))));
        regCom(this.getName(),setTabCom(setComDesc(setComUsa(setComAlias(newPluginCommand("fly",new FlyCommand(),this),"flight","useflight","setflight","usefly","setFly","efly","飞行"),StringUtils.translateColorCodes(getInstance().Message.getString("Fly.Usage")).replace("$prefix","")),StringUtils.translateColorCodes(getInstance().Message.getString("Fly.Usage_Explanation"))),this));
    }

    private void regTabCms(){
        new GrewEssentialsCommand().initChildCommands();
    }
}
