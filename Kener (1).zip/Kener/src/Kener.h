#define UNICODE

#include <iostream>
#include <unordered_map>
#include <functional>
#include <thread>
#include <windows.h>
#include <windowsx.h>
#include <commctrl.h>
#include <uxtheme.h>


#define STATIC(code) static struct STATIC{STATIC()code}STATIC;

extern HFONT defaultFont;

namespace Kener
{
    class Kener
    {
    public:
        HINSTANCE process=NULL;
        int showCmd;
    };
    extern Kener instance;
};
class Window
{
protected:
    WNDCLASSEX wc;
    HWND hWnd;
    std::thread *thread;
    std::unordered_map<UINT,std::function<UINT(WPARAM,LPARAM)>> msgProcessors;
public:
    Window();
    ~Window();
    void open();
    void join();
    void regMsgProcessor(UINT msg,std::function<UINT(WPARAM,LPARAM)> process);
};
class ClientWindow: public Window
{
public:
    ClientWindow();
};

HWND createButton(HWND parent,LPCTSTR text);
void setFont(HWND hWnd,HFONT hFont);
void setDefaultFont(HWND hWnd);
