#include "Kener.h"

ClientWindow::ClientWindow():Window()
{
    wc.lpszClassName=TEXT("KenerClient");
    wc.hIconSm=LoadIcon(wc.hInstance,TEXT("icon"));
    regMsgProcessor(WM_CREATE,[&](WPARAM wParam,LPARAM lParam)->UINT
    {
        createButton(hWnd,TEXT("awa"));
        return 0;
    });
    regMsgProcessor(WM_DESTROY,[&](WPARAM wParam,LPARAM lParam)->UINT
    {
        PostQuitMessage(0);
        return 0;
    });
}
