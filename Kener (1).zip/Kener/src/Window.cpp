#include "Kener.h"

static Window *tempThiz;
Window::Window()
{
    wc.lpszClassName=TEXT("Unknown");
    wc.lpfnWndProc=[](HWND hWnd,UINT msg,WPARAM wParam,LPARAM lParam)->LRESULT CALLBACK
    {
        static Window *thiz;
        if(thiz==nullptr)
        {
            thiz=tempThiz;
            thiz->hWnd=hWnd;
        }
        auto processor=thiz->msgProcessors.find(msg);
        if(processor!=thiz->msgProcessors.end())
            return processor->second(wParam,lParam);
        else
            return DefWindowProc(hWnd,msg,wParam,lParam);
    };
    wc.cbSize=sizeof(WNDCLASSEX);
    wc.hInstance=Kener::instance.process;
    wc.hbrBackground = (HBRUSH)(COLOR_BACKGROUND);
    wc.hIcon=LoadIcon(wc.hInstance,TEXT("icon"));
    wc.hIconSm=LoadIcon(wc.hInstance,TEXT("icon"));
    wc.hCursor=LoadCursor(nullptr,IDC_ARROW);
    hWnd=nullptr;
    thread=nullptr;
}
void Window::open()
{
    thread=new std::thread([&]
    {
        if(GetClassInfoEx(wc.hInstance,wc.lpszClassName,&wc)==FALSE)
            RegisterClassEx(&wc);
        tempThiz=this;
        CreateWindowEx(WS_EX_CLIENTEDGE,wc.lpszClassName,TEXT("Kener"),WS_OVERLAPPEDWINDOW,CW_USEDEFAULT,CW_USEDEFAULT,CW_USEDEFAULT,CW_USEDEFAULT,nullptr,nullptr,wc.hInstance,nullptr);
        ShowWindow(hWnd,Kener::instance.showCmd);
        UpdateWindow(hWnd);
        MSG msg;
        while(GetMessage(&msg,nullptr,0,0))
        {
            TranslateMessage(&msg);
            DispatchMessage(&msg);
        }
    });
}
void Window::regMsgProcessor(UINT msg,std::function<UINT(WPARAM,LPARAM)> process)
{
    this->msgProcessors[msg]=process;
}
Window::~Window()
{
    if(IsWindow(hWnd))
        DestroyWindow(hWnd);
    join();
    if(thread)
        delete thread;
}
void Window::join()
{
    if(thread)
        thread->join();
}
