#include "Kener.h"

Kener::Kener Kener::instance;

LONG WINAPI MyUnhandledExceptionFilter(EXCEPTION_POINTERS* ExceptionInfo)
{
    MessageBox(0,std::to_wstring(ExceptionInfo->ExceptionRecord->ExceptionCode).c_str(),0,0);
    return EXCEPTION_CONTINUE_SEARCH;
}

int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow)
{
    SetUnhandledExceptionFilter(MyUnhandledExceptionFilter);

    Kener::instance.process=hInstance;
    Kener::instance.showCmd=nCmdShow;

    ClientWindow window;
    window.open();
    window.join();
    return 0;
}
