#include "Kener.h"

HFONT defaultFont;

STATIC(
{
    INITCOMMONCONTROLSEX icc={};
    icc.dwSize=sizeof(INITCOMMONCONTROLSEX);
    icc.dwICC=ICC_STANDARD_CLASSES|ICC_WIN95_CLASSES|ICC_ANIMATE_CLASS|ICC_COOL_CLASSES;
    InitCommonControlsEx(&icc);
    
    LOGFONT logFont;
    SystemParametersInfo(SPI_GETICONTITLELOGFONT,sizeof(logFont),&logFont,0);
    defaultFont=CreateFontIndirect(&logFont);
})

void setFont(HWND hWnd,HFONT hFont)
{
    SendMessage(hWnd,WM_SETFONT,(WPARAM)hFont,MAKELPARAM(TRUE,0));
}
void setDefaultFont(HWND hWnd)
{
    setFont(hWnd,defaultFont);
}
HWND createButton(HWND parent,LPCTSTR text)
{
    HWND ans=CreateWindowEx(WS_EX_TRANSPARENT,WC_BUTTON,text,WS_TABSTOP|WS_VISIBLE|WS_CHILD|BS_FLAT|BS_PUSHBUTTON|BS_CENTER|BS_VCENTER,100,100,100,100,parent,(HMENU)NULL,Kener::instance.process,NULL);
    setDefaultFont(ans);
    return ans;
}
