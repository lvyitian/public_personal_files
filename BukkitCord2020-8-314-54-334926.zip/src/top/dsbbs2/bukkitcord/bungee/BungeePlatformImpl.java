package top.dsbbs2.bukkitcord.bungee;

import net.md_5.bungee.*;
import net.md_5.bungee.api.*;
import org.bukkit.*;
import top.dsbbs2.bukkitcord.api.*;
import top.dsbbs2.bukkitcord.bukkit.*;

import java.util.*;

public class BungeePlatformImpl implements IPlatform {
    private final BungeePluginManagerImpl pluginManager=new BungeePluginManagerImpl();
    {
        PlatformManager.setPlatform(this);
    }

    @Override
    public IPluginManager getPluginManager() {
        return pluginManager;
    }

    @Override
    public void dispatchCommand(ICommandSender sender, String cmd) {
        ProxyServer.getInstance().getPluginManager().dispatchCommand((CommandSender) sender.getDelegate(),cmd);
    }

    @Override
    public ICommandSender getConSoleSender() {
        return new BungeeCommandSenderImpl(ProxyServer.getInstance().getConsole());
    }

    @Override
    public IPlayer getPlayer(String n) {
        return new BungeePlayerImpl(BungeeCord.getInstance().getPlayer(n));
    }

    @Override
    public IPlayer getPlayer(UUID u) {
        return new BukkitPlayerImpl(Bukkit.getPlayer(u));
    }
}
