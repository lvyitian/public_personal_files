package top.dsbbs2.bukkitcord.bungee;

import net.md_5.bungee.api.connection.*;
import top.dsbbs2.bukkitcord.api.*;

public class BungeePlayerImpl extends BungeeCommandSenderImpl implements IPlayer {

    @Override
    public ProxiedPlayer getDelegate() {
        return player;
    }

    private final ProxiedPlayer player;
    public BungeePlayerImpl(ProxiedPlayer player)
    {
        super(player);
        this.player=player;
    }
}
