package top.dsbbs2.bukkitcord.bungee;

import top.dsbbs2.bukkitcord.api.*;

public class BungeeBootstrap extends BungeePluginImpl {
    {
        PlatformManager.setBootstrapPlugin(this);
        new BungeePlatformImpl();
    }
}
