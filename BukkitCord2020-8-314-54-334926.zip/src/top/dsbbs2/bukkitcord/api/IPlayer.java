package top.dsbbs2.bukkitcord.api;

public interface IPlayer extends ICommandSender {
}
