package top.dsbbs2.bukkitcord.api;

import top.dsbbs2.bukkitcord.bukkit.*;
import top.dsbbs2.bukkitcord.bungee.*;

public class PlatformManager {
    private static IPlatform platform;
    private static IPlugin bootstrapPlugin;
    public static IPlatform getPlatform()
    {
        return  PlatformManager.platform;
    }
    public static void setPlatform(IPlatform platform)
    {
        if (PlatformManager.platform==null)
          PlatformManager.platform=platform;
        else throw new IllegalStateException("platform");
    }
    public static IPlugin getBootstrapPlugin()
    {
        return PlatformManager.bootstrapPlugin;
    }
    public static void setBootstrapPlugin(IPlugin bootstrapPlugin)
    {
        if (PlatformManager.bootstrapPlugin==null)
            PlatformManager.bootstrapPlugin=bootstrapPlugin;
        else throw new IllegalStateException("bootstrapPlugin");
    }
    public static Platform getCurrentPlatform()
    {
        if (platform instanceof BukkitPlatformImpl)
            return Platform.BUKKIT;
        if (platform instanceof BungeePlatformImpl)
            return Platform.BUNGEE;
        return Platform.UNKNOWN;
    }
    public static ICommandRegistry getCurrentPlatformCommandRegistry()
    {
        if (platform instanceof BukkitPlatformImpl)
            return BukkitCommandRegistryImpl.INSTANCE;
        if (platform instanceof BungeePlatformImpl)
            return BungeeCommandRegistryImpl.INSTANCE;
        return null;
    }
}
