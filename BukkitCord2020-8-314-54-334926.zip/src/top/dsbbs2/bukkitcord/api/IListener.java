package top.dsbbs2.bukkitcord.api;

public interface IListener {
}
