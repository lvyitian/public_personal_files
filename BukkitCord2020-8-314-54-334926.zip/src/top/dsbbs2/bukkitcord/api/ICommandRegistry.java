package top.dsbbs2.bukkitcord.api;

import java.util.*;

public interface ICommandRegistry {
    Vector<ICommand> getCommands();
    ICommand setTabCom(final ICommand pc, final ITabCompleter tc);
    ICommand setComUsa(final ICommand pc, final String u);
    ICommand setComPer(final ICommand pc, final String p);
    ICommand setComAlias(final ICommand pc, final String... alias);
    void regComWithoutRecording(final IPlugin plugin, final ICommand c);
    void regCom(final IPlugin plugin, final ICommand c);
    void regComWithCompleter(final IPlugin plugin, final ICommand c);
    ICommand newPluginCommand(final String name, final ICommandExecutor ce, final IPlugin plugin);
    ICommand newPluginCommand(final String name, final IPlugin plugin);
}
