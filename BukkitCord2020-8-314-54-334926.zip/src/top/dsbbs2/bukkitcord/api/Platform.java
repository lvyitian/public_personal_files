package top.dsbbs2.bukkitcord.api;

public enum Platform {
    BUKKIT,
    BUNGEE,
    UNKNOWN
}
