package top.dsbbs2.bukkitcord.bukkit;
import top.dsbbs2.bukkitcord.api.*;

public class BukkitBootstrap extends BukkitPluginImpl {
    {
        PlatformManager.setBootstrapPlugin(this);
        new BukkitPlatformImpl();
    }
}
