package top.dsbbs2.bukkitcord.bukkit;

import org.bukkit.entity.*;
import top.dsbbs2.bukkitcord.api.*;

public class BukkitPlayerImpl extends BukkitCommandSenderImpl implements IPlayer {

    @Override
    public Player getDelegate() {
        return i;
    }

    private final Player i;
    public BukkitPlayerImpl(Player i)
    {
        super(i);
        this.i=i;
    }
}
