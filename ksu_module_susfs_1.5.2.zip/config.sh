# default values
hide_cusrom=0
hide_vendor_sepolicy=0
hide_compat_matrix=0
hide_gapps=0
hide_revanced=1
spoof_cmdline=0
hide_loops=1
force_hide_lsposed=0