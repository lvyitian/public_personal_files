/*
 * Decompiled with CFR 0.152.
 */
package net.minecraft.server;

import net.minecraft.server.WorldGenerationProgressListener;

public interface WorldGenerationProgressListenerFactory {
    public WorldGenerationProgressListener create(int var1);
}

