/*
 * Decompiled with CFR 0.152.
 */
package net.minecraft.block;

import net.minecraft.util.DyeColor;

public interface Stainable {
    public DyeColor getColor();
}

