/*
 * Decompiled with CFR 0.152.
 */
package net.minecraft.block;

public interface OperatorBlock {
}

