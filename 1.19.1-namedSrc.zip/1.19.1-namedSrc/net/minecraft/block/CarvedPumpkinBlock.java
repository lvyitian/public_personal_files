/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.jetbrains.annotations.Nullable
 */
package net.minecraft.block;

import java.util.function.Predicate;
import net.minecraft.advancement.criterion.Criteria;
import net.minecraft.block.AbstractBlock;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.HorizontalFacingBlock;
import net.minecraft.block.Material;
import net.minecraft.block.pattern.BlockPattern;
import net.minecraft.block.pattern.BlockPatternBuilder;
import net.minecraft.block.pattern.CachedBlockPosition;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.passive.IronGolemEntity;
import net.minecraft.entity.passive.SnowGolemEntity;
import net.minecraft.item.ItemPlacementContext;
import net.minecraft.item.Wearable;
import net.minecraft.predicate.block.BlockStatePredicate;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.state.StateManager;
import net.minecraft.state.property.DirectionProperty;
import net.minecraft.util.function.MaterialPredicate;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.world.World;
import net.minecraft.world.WorldEvents;
import net.minecraft.world.WorldView;
import org.jetbrains.annotations.Nullable;

public class CarvedPumpkinBlock
extends HorizontalFacingBlock
implements Wearable {
    public static final DirectionProperty FACING = HorizontalFacingBlock.FACING;
    @Nullable
    private BlockPattern snowGolemDispenserPattern;
    @Nullable
    private BlockPattern snowGolemPattern;
    @Nullable
    private BlockPattern ironGolemDispenserPattern;
    @Nullable
    private BlockPattern ironGolemPattern;
    private static final Predicate<BlockState> IS_GOLEM_HEAD_PREDICATE = state -> state != null && (state.isOf(Blocks.CARVED_PUMPKIN) || state.isOf(Blocks.JACK_O_LANTERN));

    protected CarvedPumpkinBlock(AbstractBlock.Settings arg) {
        super(arg);
        this.setDefaultState((BlockState)((BlockState)this.stateManager.getDefaultState()).with(FACING, Direction.NORTH));
    }

    @Override
    public void onBlockAdded(BlockState state, World world, BlockPos pos, BlockState oldState, boolean notify) {
        if (oldState.isOf(state.getBlock())) {
            return;
        }
        this.trySpawnEntity(world, pos);
    }

    public boolean canDispense(WorldView world, BlockPos pos) {
        return this.getSnowGolemDispenserPattern().searchAround(world, pos) != null || this.getIronGolemDispenserPattern().searchAround(world, pos) != null;
    }

    private void trySpawnEntity(World world, BlockPos pos) {
        block9: {
            BlockPattern.Result lv;
            block8: {
                lv = this.getSnowGolemPattern().searchAround(world, pos);
                if (lv == null) break block8;
                for (int i = 0; i < this.getSnowGolemPattern().getHeight(); ++i) {
                    CachedBlockPosition lv2 = lv.translate(0, i, 0);
                    world.setBlockState(lv2.getBlockPos(), Blocks.AIR.getDefaultState(), Block.NOTIFY_LISTENERS);
                    world.syncWorldEvent(WorldEvents.BLOCK_BROKEN, lv2.getBlockPos(), Block.getRawIdFromState(lv2.getBlockState()));
                }
                SnowGolemEntity lv3 = EntityType.SNOW_GOLEM.create(world);
                BlockPos lv4 = lv.translate(0, 2, 0).getBlockPos();
                lv3.refreshPositionAndAngles((double)lv4.getX() + 0.5, (double)lv4.getY() + 0.05, (double)lv4.getZ() + 0.5, 0.0f, 0.0f);
                world.spawnEntity(lv3);
                for (ServerPlayerEntity lv5 : world.getNonSpectatingEntities(ServerPlayerEntity.class, lv3.getBoundingBox().expand(5.0))) {
                    Criteria.SUMMONED_ENTITY.trigger(lv5, lv3);
                }
                for (int j = 0; j < this.getSnowGolemPattern().getHeight(); ++j) {
                    CachedBlockPosition lv6 = lv.translate(0, j, 0);
                    world.updateNeighbors(lv6.getBlockPos(), Blocks.AIR);
                }
                break block9;
            }
            lv = this.getIronGolemPattern().searchAround(world, pos);
            if (lv == null) break block9;
            for (int i = 0; i < this.getIronGolemPattern().getWidth(); ++i) {
                for (int k = 0; k < this.getIronGolemPattern().getHeight(); ++k) {
                    CachedBlockPosition lv7 = lv.translate(i, k, 0);
                    world.setBlockState(lv7.getBlockPos(), Blocks.AIR.getDefaultState(), Block.NOTIFY_LISTENERS);
                    world.syncWorldEvent(WorldEvents.BLOCK_BROKEN, lv7.getBlockPos(), Block.getRawIdFromState(lv7.getBlockState()));
                }
            }
            BlockPos lv8 = lv.translate(1, 2, 0).getBlockPos();
            IronGolemEntity lv9 = EntityType.IRON_GOLEM.create(world);
            lv9.setPlayerCreated(true);
            lv9.refreshPositionAndAngles((double)lv8.getX() + 0.5, (double)lv8.getY() + 0.05, (double)lv8.getZ() + 0.5, 0.0f, 0.0f);
            world.spawnEntity(lv9);
            for (ServerPlayerEntity lv5 : world.getNonSpectatingEntities(ServerPlayerEntity.class, lv9.getBoundingBox().expand(5.0))) {
                Criteria.SUMMONED_ENTITY.trigger(lv5, lv9);
            }
            for (int j = 0; j < this.getIronGolemPattern().getWidth(); ++j) {
                for (int l = 0; l < this.getIronGolemPattern().getHeight(); ++l) {
                    CachedBlockPosition lv10 = lv.translate(j, l, 0);
                    world.updateNeighbors(lv10.getBlockPos(), Blocks.AIR);
                }
            }
        }
    }

    @Override
    public BlockState getPlacementState(ItemPlacementContext ctx) {
        return (BlockState)this.getDefaultState().with(FACING, ctx.getPlayerFacing().getOpposite());
    }

    @Override
    protected void appendProperties(StateManager.Builder<Block, BlockState> builder) {
        builder.add(FACING);
    }

    private BlockPattern getSnowGolemDispenserPattern() {
        if (this.snowGolemDispenserPattern == null) {
            this.snowGolemDispenserPattern = BlockPatternBuilder.start().aisle(" ", "#", "#").where('#', CachedBlockPosition.matchesBlockState(BlockStatePredicate.forBlock(Blocks.SNOW_BLOCK))).build();
        }
        return this.snowGolemDispenserPattern;
    }

    private BlockPattern getSnowGolemPattern() {
        if (this.snowGolemPattern == null) {
            this.snowGolemPattern = BlockPatternBuilder.start().aisle("^", "#", "#").where('^', CachedBlockPosition.matchesBlockState(IS_GOLEM_HEAD_PREDICATE)).where('#', CachedBlockPosition.matchesBlockState(BlockStatePredicate.forBlock(Blocks.SNOW_BLOCK))).build();
        }
        return this.snowGolemPattern;
    }

    private BlockPattern getIronGolemDispenserPattern() {
        if (this.ironGolemDispenserPattern == null) {
            this.ironGolemDispenserPattern = BlockPatternBuilder.start().aisle("~ ~", "###", "~#~").where('#', CachedBlockPosition.matchesBlockState(BlockStatePredicate.forBlock(Blocks.IRON_BLOCK))).where('~', CachedBlockPosition.matchesBlockState(MaterialPredicate.create(Material.AIR))).build();
        }
        return this.ironGolemDispenserPattern;
    }

    private BlockPattern getIronGolemPattern() {
        if (this.ironGolemPattern == null) {
            this.ironGolemPattern = BlockPatternBuilder.start().aisle("~^~", "###", "~#~").where('^', CachedBlockPosition.matchesBlockState(IS_GOLEM_HEAD_PREDICATE)).where('#', CachedBlockPosition.matchesBlockState(BlockStatePredicate.forBlock(Blocks.IRON_BLOCK))).where('~', CachedBlockPosition.matchesBlockState(MaterialPredicate.create(Material.AIR))).build();
        }
        return this.ironGolemPattern;
    }
}

