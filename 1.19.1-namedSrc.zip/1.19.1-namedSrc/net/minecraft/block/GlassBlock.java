/*
 * Decompiled with CFR 0.152.
 */
package net.minecraft.block;

import net.minecraft.block.AbstractBlock;
import net.minecraft.block.AbstractGlassBlock;

public class GlassBlock
extends AbstractGlassBlock {
    public GlassBlock(AbstractBlock.Settings arg) {
        super(arg);
    }
}

