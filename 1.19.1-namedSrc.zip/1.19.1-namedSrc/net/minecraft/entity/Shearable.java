/*
 * Decompiled with CFR 0.152.
 */
package net.minecraft.entity;

import net.minecraft.sound.SoundCategory;

public interface Shearable {
    public void sheared(SoundCategory var1);

    public boolean isShearable();
}

