/*
 * Decompiled with CFR 0.152.
 */
package net.minecraft.entity;

public class EntityGroup {
    public static final EntityGroup DEFAULT = new EntityGroup();
    public static final EntityGroup UNDEAD = new EntityGroup();
    public static final EntityGroup ARTHROPOD = new EntityGroup();
    public static final EntityGroup ILLAGER = new EntityGroup();
    public static final EntityGroup AQUATIC = new EntityGroup();
}

