/*
 * Decompiled with CFR 0.152.
 */
package net.minecraft.entity;

import net.minecraft.entity.player.PlayerEntity;

public interface RideableInventory {
    public void openInventory(PlayerEntity var1);
}

