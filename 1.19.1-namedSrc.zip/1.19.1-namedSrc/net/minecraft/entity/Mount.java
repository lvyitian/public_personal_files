/*
 * Decompiled with CFR 0.152.
 */
package net.minecraft.entity;

public interface Mount {
}

