/*
 * Decompiled with CFR 0.152.
 */
package net.minecraft.entity;

import java.util.Map;
import net.minecraft.util.math.Vec3f;

public interface AngledModelEntity {
    public Map<String, Vec3f> getModelAngles();
}

