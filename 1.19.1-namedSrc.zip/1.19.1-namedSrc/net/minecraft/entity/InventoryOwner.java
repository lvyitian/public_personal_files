/*
 * Decompiled with CFR 0.152.
 */
package net.minecraft.entity;

import net.minecraft.entity.ItemEntity;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.inventory.SimpleInventory;
import net.minecraft.item.ItemStack;

public interface InventoryOwner {
    public SimpleInventory getInventory();

    public static void pickUpItem(MobEntity entity, InventoryOwner inventoryOwner, ItemEntity item) {
        ItemStack lv = item.getStack();
        if (entity.canGather(lv)) {
            SimpleInventory lv2 = inventoryOwner.getInventory();
            boolean bl = lv2.canInsert(lv);
            if (!bl) {
                return;
            }
            entity.triggerItemPickedUpByEntityCriteria(item);
            int i = lv.getCount();
            ItemStack lv3 = lv2.addStack(lv);
            entity.sendPickup(item, i - lv3.getCount());
            if (lv3.isEmpty()) {
                item.discard();
            } else {
                lv.setCount(lv3.getCount());
            }
        }
    }
}

