/*
 * Decompiled with CFR 0.152.
 */
package net.minecraft.entity;

import net.minecraft.item.ItemStack;

public interface FlyingItemEntity {
    public ItemStack getStack();
}

