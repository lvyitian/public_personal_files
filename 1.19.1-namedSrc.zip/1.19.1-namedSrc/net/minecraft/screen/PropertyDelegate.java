/*
 * Decompiled with CFR 0.152.
 */
package net.minecraft.screen;

public interface PropertyDelegate {
    public int get(int var1);

    public void set(int var1, int var2);

    public int size();
}

