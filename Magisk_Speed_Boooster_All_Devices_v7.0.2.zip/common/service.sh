#!/system/bin/sh
# Please don't hardcode /magisk/modname/... ; instead, please use $MODDIR/...
# This will make your scripts compatible even if Magisk change its mount point in the future
MODDIR=${0%/*}

# This script will be executed in late_start service mode
# More info in the main Magisk thread

# Wait for boot to be completed
while [ `getprop vendor.post_boot.parsed` != "1" ]; do
    sleep 1s
done

# Apply settings
sleep 90s

# Core control parameters
echo 1 > /sys/devices/system/cpu/cpu0/core_ctl/enable
echo 1 > /sys/devices/system/cpu/cpu0/core_ctl/min_cpus
echo 4 > /sys/devices/system/cpu/cpu0/core_ctl/max_cpus
echo 100 > /sys/devices/system/cpu/cpu0/core_ctl/offline_delay_ms
echo 0 > /sys/devices/system/cpu/cpu0/core_ctl/is_big_cluster
echo 1 > /sys/devices/system/cpu/cpu4/core_ctl/enable
echo 2 > /sys/devices/system/cpu/cpu4/core_ctl/min_cpus
echo 4 > /sys/devices/system/cpu/cpu4/core_ctl/max_cpus
echo 70 > /sys/devices/system/cpu/cpu4/core_ctl/busy_up_thres
echo 60 > /sys/devices/system/cpu/cpu4/core_ctl/busy_down_thres
echo 100 > /sys/devices/system/cpu/cpu4/core_ctl/offline_delay_ms
echo 1 > /sys/devices/system/cpu/cpu4/core_ctl/is_big_cluster
echo 4 > /sys/devices/system/cpu/cpu4/core_ctl/task_thres

# Setting b.L scheduler parameters
echo 95 > /proc/sys/kernel/sched_upmigrate
echo 85 > /proc/sys/kernel/sched_downmigrate
echo 100 > /proc/sys/kernel/sched_group_upmigrate
echo 95 > /proc/sys/kernel/sched_group_downmigrate

# CPU setting
echo '4:2803200' > /sys/module/msm_performance/parameters/cpu_max_freq
echo '5:2803200' > /sys/module/msm_performance/parameters/cpu_max_freq
echo '6:2803200' > /sys/module/msm_performance/parameters/cpu_max_freq
echo '7:2803200' > /sys/module/msm_performance/parameters/cpu_max_freq
chmod 644 /sys/devices/system/cpu/cpu4/cpufreq/scaling_max_freq
echo '2803200' > /sys/devices/system/cpu/cpu4/cpufreq/scaling_max_freq
chmod 444 /sys/devices/system/cpu/cpu4/cpufreq/scaling_max_freq
chmod 644 /sys/devices/system/cpu/cpu5/cpufreq/scaling_max_freq
echo '2803200' > /sys/devices/system/cpu/cpu5/cpufreq/scaling_max_freq
chmod 444 /sys/devices/system/cpu/cpu5/cpufreq/scaling_max_freq
chmod 644 /sys/devices/system/cpu/cpu6/cpufreq/scaling_max_freq
echo '2803200' > /sys/devices/system/cpu/cpu6/cpufreq/scaling_max_freq
chmod 444 /sys/devices/system/cpu/cpu6/cpufreq/scaling_max_freq
chmod 644 /sys/devices/system/cpu/cpu7/cpufreq/scaling_max_freq
echo '2803200' > /sys/devices/system/cpu/cpu7/cpufreq/scaling_max_freq
chmod 444 /sys/devices/system/cpu/cpu7/cpufreq/scaling_max_freq
echo '4:825600' > /sys/module/msm_performance/parameters/cpu_min_freq
echo '5:825600' > /sys/module/msm_performance/parameters/cpu_min_freq
echo '6:825600' > /sys/module/msm_performance/parameters/cpu_min_freq
echo '7:825600' > /sys/module/msm_performance/parameters/cpu_min_freq
chmod 644 /sys/devices/system/cpu/cpu4/cpufreq/scaling_min_freq
echo '825600' > /sys/devices/system/cpu/cpu4/cpufreq/scaling_min_freq
chmod 444 /sys/devices/system/cpu/cpu4/cpufreq/scaling_min_freq
chmod 644 /sys/devices/system/cpu/cpu5/cpufreq/scaling_min_freq
echo '825600' > /sys/devices/system/cpu/cpu5/cpufreq/scaling_min_freq
chmod 444 /sys/devices/system/cpu/cpu5/cpufreq/scaling_min_freq
chmod 644 /sys/devices/system/cpu/cpu6/cpufreq/scaling_min_freq
echo '825600' > /sys/devices/system/cpu/cpu6/cpufreq/scaling_min_freq
chmod 444 /sys/devices/system/cpu/cpu6/cpufreq/scaling_min_freq
chmod 644 /sys/devices/system/cpu/cpu7/cpufreq/scaling_min_freq
echo '825600' > /sys/devices/system/cpu/cpu7/cpufreq/scaling_min_freq
chmod 444 /sys/devices/system/cpu/cpu7/cpufreq/scaling_min_freq
chmod 644 /sys/devices/system/cpu/cpu4/cpufreq/scaling_governor
echo 'schedutil' > /sys/devices/system/cpu/cpu4/cpufreq/scaling_governor
chmod 444 /sys/devices/system/cpu/cpu4/cpufreq/scaling_governor
chmod 644 /sys/devices/system/cpu/cpu5/cpufreq/scaling_governor
echo 'schedutil' > /sys/devices/system/cpu/cpu5/cpufreq/scaling_governor
chmod 444 /sys/devices/system/cpu/cpu5/cpufreq/scaling_governor
chmod 644 /sys/devices/system/cpu/cpu6/cpufreq/scaling_governor
echo 'schedutil' > /sys/devices/system/cpu/cpu6/cpufreq/scaling_governor
chmod 444 /sys/devices/system/cpu/cpu6/cpufreq/scaling_governor
chmod 644 /sys/devices/system/cpu/cpu7/cpufreq/scaling_governor
echo 'schedutil' > /sys/devices/system/cpu/cpu7/cpufreq/scaling_governor
chmod 444 /sys/devices/system/cpu/cpu7/cpufreq/scaling_governor
echo '0:1766400' > /sys/module/msm_performance/parameters/cpu_max_freq
echo '1:1766400' > /sys/module/msm_performance/parameters/cpu_max_freq
echo '2:1766400' > /sys/module/msm_performance/parameters/cpu_max_freq
echo '3:1766400' > /sys/module/msm_performance/parameters/cpu_max_freq
chmod 644 /sys/devices/system/cpu/cpu0/cpufreq/scaling_max_freq
echo '1766400' > /sys/devices/system/cpu/cpu0/cpufreq/scaling_max_freq
chmod 444 /sys/devices/system/cpu/cpu0/cpufreq/scaling_max_freq
chmod 644 /sys/devices/system/cpu/cpu1/cpufreq/scaling_max_freq
echo '1766400' > /sys/devices/system/cpu/cpu1/cpufreq/scaling_max_freq
chmod 444 /sys/devices/system/cpu/cpu1/cpufreq/scaling_max_freq
chmod 644 /sys/devices/system/cpu/cpu2/cpufreq/scaling_max_freq
echo '1766400' > /sys/devices/system/cpu/cpu2/cpufreq/scaling_max_freq
chmod 444 /sys/devices/system/cpu/cpu2/cpufreq/scaling_max_freq
chmod 644 /sys/devices/system/cpu/cpu3/cpufreq/scaling_max_freq
echo '1766400' > /sys/devices/system/cpu/cpu3/cpufreq/scaling_max_freq
chmod 444 /sys/devices/system/cpu/cpu3/cpufreq/scaling_max_freq
echo '0:300000' > /sys/module/msm_performance/parameters/cpu_min_freq
echo '1:300000' > /sys/module/msm_performance/parameters/cpu_min_freq
echo '2:300000' > /sys/module/msm_performance/parameters/cpu_min_freq
echo '3:300000' > /sys/module/msm_performance/parameters/cpu_min_freq
chmod 644 /sys/devices/system/cpu/cpu0/cpufreq/scaling_min_freq
echo '300000' > /sys/devices/system/cpu/cpu0/cpufreq/scaling_min_freq
chmod 444 /sys/devices/system/cpu/cpu0/cpufreq/scaling_min_freq
chmod 644 /sys/devices/system/cpu/cpu1/cpufreq/scaling_min_freq
echo '300000' > /sys/devices/system/cpu/cpu1/cpufreq/scaling_min_freq
chmod 444 /sys/devices/system/cpu/cpu1/cpufreq/scaling_min_freq
chmod 644 /sys/devices/system/cpu/cpu2/cpufreq/scaling_min_freq
echo '300000' > /sys/devices/system/cpu/cpu2/cpufreq/scaling_min_freq
chmod 444 /sys/devices/system/cpu/cpu2/cpufreq/scaling_min_freq
chmod 644 /sys/devices/system/cpu/cpu3/cpufreq/scaling_min_freq
echo '300000' > /sys/devices/system/cpu/cpu3/cpufreq/scaling_min_freq
chmod 444 /sys/devices/system/cpu/cpu3/cpufreq/scaling_min_freq
chmod 644 /sys/devices/system/cpu/cpu0/cpufreq/scaling_governor
echo 'schedutil' > /sys/devices/system/cpu/cpu0/cpufreq/scaling_governor
chmod 444 /sys/devices/system/cpu/cpu0/cpufreq/scaling_governor
chmod 644 /sys/devices/system/cpu/cpu1/cpufreq/scaling_governor
echo 'schedutil' > /sys/devices/system/cpu/cpu1/cpufreq/scaling_governor
chmod 444 /sys/devices/system/cpu/cpu1/cpufreq/scaling_governor
chmod 644 /sys/devices/system/cpu/cpu2/cpufreq/scaling_governor
echo 'schedutil' > /sys/devices/system/cpu/cpu2/cpufreq/scaling_governor
chmod 444 /sys/devices/system/cpu/cpu2/cpufreq/scaling_governor
chmod 644 /sys/devices/system/cpu/cpu3/cpufreq/scaling_governor
echo 'schedutil' > /sys/devices/system/cpu/cpu3/cpufreq/scaling_governor
chmod 444 /sys/devices/system/cpu/cpu3/cpufreq/scaling_governor


# CPU Boost
echo "0:0 4:0" > /sys/module/cpu_boost/parameters/topkek_boost_freq
echo '100' > /sys/module/cpu_boost/parameters/topkek_boost_ms
echo '0:0' > /sys/module/cpu_boost/parameters/input_boost_freq
echo '1:0' > /sys/module/cpu_boost/parameters/input_boost_freq
echo '2:0' > /sys/module/cpu_boost/parameters/input_boost_freq
echo '3:0' > /sys/module/cpu_boost/parameters/input_boost_freq
echo '4:0' > /sys/module/cpu_boost/parameters/input_boost_freq
echo '5:0' > /sys/module/cpu_boost/parameters/input_boost_freq
echo '6:0' > /sys/module/cpu_boost/parameters/input_boost_freq
echo '7:0' > /sys/module/cpu_boost/parameters/input_boost_freq
echo '100' > /sys/module/cpu_boost/parameters/input_boost_ms

echo '20000' > /sys/devices/system/cpu/cpufreq/policy0/schedutil/down_rate_limit_us
echo '1000' > /sys/devices/system/cpu/cpufreq/policy0/schedutil/up_rate_limit_us	
echo '1' > /sys/devices/system/cpu/cpufreq/policy0/schedutil/iowait_boost_enable
echo '1209600' > /sys/devices/system/cpu/cpufreq/policy0/schedutil/hispeed_freq
echo '90' > /sys/devices/system/cpu/cpufreq/policy0/schedutil/hispeed_load
echo '1' > /sys/devices/system/cpu/cpufreq/policy0/schedutil/pl
echo '20000' > /sys/devices/system/cpu/cpufreq/policy4/schedutil/down_rate_limit_us
echo '1000' > /sys/devices/system/cpu/cpufreq/policy4/schedutil/up_rate_limit_us
echo '1' > /sys/devices/system/cpu/cpufreq/policy4/schedutil/iowait_boost_enable
echo '1574400' > /sys/devices/system/cpu/cpufreq/policy4/schedutil/hispeed_freq
echo '90' > /sys/devices/system/cpu/cpufreq/policy4/schedutil/hispeed_load
echo '1' > /sys/devices/system/cpu/cpufreq/policy4/schedutil/pl

# minfree
echo 1 > /sys/module/lowmemorykiller/parameters/enable_adaptive_lmk
echo "16384,24576,32768,65536,131072,163840" > /sys/module/lowmemorykiller/parameters/minfree

# Internal SD Card Speed up
echo 'cfq' > /sys/block/sda/queue/scheduler
echo '1024' > /sys/block/sda/queue/read_ahead_kb
echo '0' > /sys/block/sda/queue/rotational
echo '0' > /sys/block/sda/queue/iostats
echo '0' > /sys/block/sda/queue/add_random
echo '1' > /sys/block/sda/queue/rq_affinity
echo '0' > /sys/block/sda/queue/nomerges
echo '1024' > /sys/block/sda/queue/nr_requests

echo 'cfq' > /sys/block/sdb/queue/scheduler
echo '1024' > /sys/block/sdb/queue/read_ahead_kb
echo '0' > /sys/block/sdb/queue/rotational
echo '0' > /sys/block/sdb/queue/iostats
echo '0' > /sys/block/sdb/queue/add_random
echo '1' > /sys/block/sdb/queue/rq_affinity
echo '0' > /sys/block/sdb/queue/nomerges
echo '1024' > /sys/block/sdb/queue/nr_requests

echo 'cfq' > /sys/block/sdc/queue/scheduler
echo '1024' > /sys/block/sdc/queue/read_ahead_kb
echo '0' > /sys/block/sdc/queue/rotational
echo '0' > /sys/block/sdc/queue/iostats
echo '0' > /sys/block/sdc/queue/add_random
echo '1' > /sys/block/sdc/queue/rq_affinity
echo '0' > /sys/block/sdc/queue/nomerges
echo '1024' > /sys/block/sdc/queue/nr_requests

echo 'cfq' > /sys/block/sdd/queue/scheduler
echo '1024' > /sys/block/sdd/queue/read_ahead_kb
echo '0' > /sys/block/sdd/queue/rotational
echo '0' > /sys/block/sdd/queue/iostats
echo '0' > /sys/block/sdd/queue/add_random
echo '1' > /sys/block/sdd/queue/rq_affinity
echo '0' > /sys/block/sdd/queue/nomerges
echo '1024' > /sys/block/sdd/queue/nr_requests

echo 'cfq' > /sys/block/sde/queue/scheduler
echo '1024' > /sys/block/sde/queue/read_ahead_kb
echo '0' > /sys/block/sde/queue/rotational
echo '0' > /sys/block/sde/queue/iostats
echo '0' > /sys/block/sde/queue/add_random
echo '1' > /sys/block/sde/queue/rq_affinity
echo '0' > /sys/block/sde/queue/nomerges
echo '1024' > /sys/block/sde/queue/nr_requests

echo 'cfq' > /sys/block/sdf/queue/scheduler
echo '1024' > /sys/block/sdf/queue/read_ahead_kb
echo '0' > /sys/block/sdf/queue/rotational
echo '0' > /sys/block/sdf/queue/iostats
echo '0' > /sys/block/sdf/queue/add_random
echo '1' > /sys/block/sdf/queue/rq_affinity
echo '0' > /sys/block/sdf/queue/nomerges
echo '1024' > /sys/block/sdf/queue/nr_requests

# External SD Card Speed up
echo 'cfq' > /sys/block/mmcblk0/queue/scheduler
echo '1024' > /sys/block/mmcblk0/queue/read_ahead_kb
echo '0' > /sys/block/mmcblk0/queue/rotational
echo '0' > /sys/block/mmcblk0/queue/iostats
echo '0' > /sys/block/mmcblk0/queue/add_random
echo '1' > /sys/block/mmcblk0/queue/rq_affinity
echo '0' > /sys/block/mmcblk0/queue/nomerges
echo '1024' > /sys/block/mmcblk0/queue/nr_requests

# Memory Tuning
echo '1024' > /sys/block/ram0/queue/read_ahead_kb
echo '1024' > /sys/block/ram1/queue/read_ahead_kb
echo '1024' > /sys/block/ram2/queue/read_ahead_kb
echo '1024' > /sys/block/ram3/queue/read_ahead_kb
echo '1024' > /sys/block/ram4/queue/read_ahead_kb
echo '1024' > /sys/block/ram5/queue/read_ahead_kb
echo '1024' > /sys/block/ram6/queue/read_ahead_kb
echo '1024' > /sys/block/ram7/queue/read_ahead_kb
echo '1024' > /sys/block/ram8/queue/read_ahead_kb
echo '1024' > /sys/block/ram9/queue/read_ahead_kb
echo '1024' > /sys/block/ram10/queue/read_ahead_kb
echo '1024' > /sys/block/ram11/queue/read_ahead_kb
echo '1024' > /sys/block/ram12/queue/read_ahead_kb
echo '1024' > /sys/block/ram13/queue/read_ahead_kb
echo '1024' > /sys/block/ram14/queue/read_ahead_kb
echo '1024' > /sys/block/ram15/queue/read_ahead_kb
echo '1024' > /sys/block/vnswap0/queue/read_ahead_kb

# ZRAM
echo '1024' > /sys/block/zram0/queue/read_ahead_kb

# Entropy
echo '128' > /proc/sys/kernel/random/read_wakeup_threshold
echo '1024' > /proc/sys/kernel/random/write_wakeup_threshold

# TCP Type
sysctl -w net.ipv4.tcp_congestion_control=cubic

# TCP Mod
echo 0 > /proc/sys/net/ipv4/conf/default/secure_redirects
echo 0 > /proc/sys/net/ipv4/conf/default/accept_redirects
echo 0 > /proc/sys/net/ipv4/conf/default/accept_source_route
echo 0 > /proc/sys/net/ipv4/conf/all/secure_redirects
echo 0 > /proc/sys/net/ipv4/conf/all/accept_redirects
echo 0 > /proc/sys/net/ipv4/conf/all/accept_source_route
echo 0 > /proc/sys/net/ipv4/ip_forward
echo 0 > /proc/sys/net/ipv4/ip_dynaddr
echo 0 > /proc/sys/net/ipv4/ip_no_pmtu_disc
echo 0 > /proc/sys/net/ipv4/tcp_ecn
echo 0 > /proc/sys/net/ipv4/tcp_timestamps
echo 1 > /proc/sys/net/ipv4/tcp_tw_reuse
echo 1 > /proc/sys/net/ipv4/tcp_fack
echo 1 > /proc/sys/net/ipv4/tcp_sack
echo 1 > /proc/sys/net/ipv4/tcp_dsack
echo 1 > /proc/sys/net/ipv4/tcp_rfc1337
echo 1 > /proc/sys/net/ipv4/tcp_tw_recycle
echo 1 > /proc/sys/net/ipv4/tcp_window_scaling
echo 1 > /proc/sys/net/ipv4/tcp_moderate_rcvbuf
echo 1 > /proc/sys/net/ipv4/tcp_no_metrics_save
echo 2 > /proc/sys/net/ipv4/tcp_synack_retries
echo 2 > /proc/sys/net/ipv4/tcp_syn_retries
echo 5 > /proc/sys/net/ipv4/tcp_keepalive_probes
echo 30 > /proc/sys/net/ipv4/tcp_keepalive_intvl
echo 30 > /proc/sys/net/ipv4/tcp_fin_timeout
echo 1800 > /proc/sys/net/ipv4/tcp_keepalive_time
echo 5505024 > /proc/sys/net/core/rmem_max
echo 5505024 > /proc/sys/net/core/wmem_max
echo 5505024 > /proc/sys/net/core/rmem_default
echo 5505024 > /proc/sys/net/core/wmem_default
echo "20480" > /proc/sys/net/core/optmem_max;
echo "524288 1048576 5505024" > /proc/sys/net/ipv4/tcp_rmem;
echo "262144 524288 5505024" > /proc/sys/net/ipv4/tcp_wmem;
echo "1" > /proc/sys/net/ipv4/icmp_echo_ignore_broadcasts;
echo "1" > /proc/sys/net/ipv4/icmp_echo_ignore_all;
echo "1" > /proc/sys/net/ipv4/icmp_ignore_bogus_error_responses;

# better idling
echo 0-3 > /dev/cpuset/restricted/cpus

# cpusets tuning
echo 100 > /sys/module/cpu_boost/parameters/input_boost_ms
echo 0-7 > /dev/cpuset/top-app/cpus
echo 0-7 > /dev/cpuset/game/cpus
echo 0-7 > /dev/cpuset/gamelite/cpus
echo "2-3,6-7" > /dev/cpuset/foreground/cpus
echo 2-3 > /dev/cpuset/background/cpus
echo 0-1 > /dev/cpuset/system-background/cpus

echo 1 > /dev/stune/top-app/schedtune.colocate
echo 1 > /dev/stune/top-app/schedtune.sched_boost_enabled
echo 1 > /dev/stune/top-app/schedtune.sched_boost_no_override
echo 0 > /dev/stune/top-app/schedtune.prefer_idle
echo 0 > /dev/stune/top-app/schedtune.boost
echo 0 > /dev/stune/foreground/schedtune.colocate
echo 1 > /dev/stune/foreground/schedtune.sched_boost_enabled
echo 0 > /dev/stune/foreground/schedtune.sched_boost_no_override
echo 0 > /dev/stune/foreground/schedtune.prefer_idle
echo 0 > /dev/stune/foreground/schedtune.boost
echo 0 > /dev/stune/background/schedtune.colocate
echo 1 > /dev/stune/background/schedtune.sched_boost_enabled
echo 0 > /dev/stune/background/schedtune.sched_boost_no_override
echo 0 > /dev/stune/background/schedtune.prefer_idle
echo 0 > /dev/stune/background/schedtune.boost
echo 0 > /dev/stune/schedtune.colocate
echo 1 > /dev/stune/schedtune.sched_boost_enabled
echo 0 > /dev/stune/schedtune.sched_boost_no_override
echo 0 > /dev/stune/schedtune.prefer_idle
echo 0 > /dev/stune/schedtune.boost

# Set swap
echo 70 > /sys/module/vmpressure/parameters/allocstall_threshold
echo 100 > /sys/module/vmpressure/parameters/vmpressure_scale_max
echo 15 > /proc/sys/vm/swappiness
echo 20 > /proc/sys/vm/dirty_ratio
echo 5 > /proc/sys/vm/dirty_background_ratio
echo 200 > /proc/sys/vm/dirty_expire_centisecs
echo 500 > /proc/sys/vm/dirty_writeback_centisecs
echo 0 > /proc/sys/vm/oom_kill_allocating_task
echo 1 > /proc/sys/vm/overcommit_memory
echo 50 > /proc/sys/vm/overcommit_ratio
echo 0 > /proc/sys/vm/drop_caches
echo 100 > /proc/sys/vm/vfs_cache_pressure

# UnThermal GPU
echo "0" > /sys/class/kgsl/kgsl-3d0/throttling

# Set Permission
chmod 664 /system/etc/hosts

# fs
echo "0" > /proc/sys/fs/dir-notify-enable
echo "20" > /proc/sys/fs/lease-break-time
echo "131072" > /proc/sys/fs/aio-max-nr

# Disable Fsync
chmod 666 /sys/module/sync/parameters/fsync_enable
chown root /sys/module/sync/parameters/fsync_enable
echo "N" > /sys/module/sync/parameters/fsync_enable

# Power Saving
chmod 664 /sys/module/workqueue/parameters/power_efficient
echo 'Y' > /sys/module/workqueue/parameters/power_efficient
echo "mem" > /sys/power/autosleep
echo "deep" > /sys/power/mem_sleep

echo "Y" > /sys/kernel/debug/dsi-panel-ebbg-fhd-ft8716-video_display/dsi-phy-0_allow_phy_power_off
echo "Y" > /sys/kernel/debug/dsi-panel-ebbg-fhd-ft8716-video_display/ulps_enable
echo "Y" > /sys/kernel/debug/dsi_panel_ebbg_fhd_ft8719_video_display/dsi-phy-0_allow_phy_power_off
echo "Y" > /sys/kernel/debug/dsi_panel_ebbg_fhd_ft8719_video_display/ulps_enable
echo "Y" > /sys/kernel/debug/dsi_panel_jdi_fhd_r63452_cmd_display/dsi-phy-0_allow_phy_power_off
echo "Y" > /sys/kernel/debug/dsi_panel_jdi_fhd_r63452_cmd_display/ulps_enable
echo "Y" > /sys/kernel/debug/dsi_panel_jdi_fhd_nt35596s_video_display/dsi-phy-0_allow_phy_power_off
echo "Y" > /sys/kernel/debug/dsi_panel_jdi_fhd_nt35596s_video_display/ulps_enable
echo "Y" > /sys/kernel/debug/dsi_tianma_fhd_nt36672a_video_display/dsi-phy-0_allow_phy_power_off
echo "Y" > /sys/kernel/debug/dsi_tianma_fhd_nt36672a_video_display/ulps_enable
echo "Y" > /sys/kernel/debug/dsi_ss_ea8074_notch_fhd_cmd_display/dsi-phy-0_allow_phy_power_off
echo "Y" > /sys/kernel/debug/dsi_ss_ea8074_notch_fhd_cmd_display/ulps_enable

fi;
