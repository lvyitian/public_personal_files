This is Yosys 0.7 for Win32.
Documentation at http://www.clifford.at/yosys/.
