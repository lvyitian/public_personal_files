package top.dsbbs2.cs;

public class Main {
  public static void main(String[] args) {
	  
  }
}
