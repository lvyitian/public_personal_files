package top.dsbbs2.cc;

public class Main {
	public static void main(String[] args) {
		
	}
}
