package top.dsbbs2.chat.common;

public enum PacketType {

}
