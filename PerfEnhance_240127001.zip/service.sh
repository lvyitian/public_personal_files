#!/system/bin/sh
execute=${0%/*}
wait_until_login() {
    while [ "$(getprop sys.boot_completed)" != "1" ]; do
        sleep 1
    done
    while [ ! -d "/sdcard/Android" ]; do
        sleep 1
    done
}
grep_prop() {
    REGEX="s/^$1=//p"
    shift
    FILES="$@"
    [ -z "$FILES" ] && FILES=/system/build.prop
    cat "$FILES" 2>/dev/null | dos2unix | sed -n "$REGEX" | head -n 1
}
wkdsp() {
    echo "id=U-executor_info
        name=.PerfEnhance
        version=$(grep_prop version "$execute"/module.prop 2>/dev/null)
        author=world.execute(darker); 酷安@darker_fun_
        minMagisk=24300
        updateJson=$(grep_prop updateJson "$execute"/module.prop 2>/dev/null)
    " >"$execute/module.prop.temp"
    if [ "$2" != "" ]; then
        echo "versionCode=$2" >>"$execute"/module.prop.temp 2>/dev/null
    else
        echo "versionCode=$(grep_prop versionCode "$execute"/module.prop 2>/dev/null)" >>"$execute"/module.prop.temp 2>/dev/null
    fi
    if [ -f "/proc/mtktz/mtktscpu" ]; then
        echo "description=[$1] 性能增强模块，解锁核心温度并控制 Repo: https://www.coolapk.com/feed/40483786" >>"$execute"/module.prop.temp 2>/dev/null
    else
        echo "description=[$1] 性能增强模块，解锁核心温度 Repo: https://www.coolapk.com/feed/40483786" >>"$execute"/module.prop.temp 2>/dev/null
    fi
    mv "$execute"/module.prop.temp "$execute"/module.prop 2>/dev/null
}
wait_until_login
rm -rf /data/adb/modules*/uperf_enhance*
rm -rf /data/media/0/Android/MTK-Enhance*
mkdir -p /data/media/0/Android/darker/PerfEnhance
mv /data/media/0/Android/darker/PerfEnhance/PerfEnhance.log /data/media/0/Android/darker/PerfEnhance/PerfEnhance.lastboot.log
nohup "$execute"/bin/PerfEnhance_main >>/data/media/0/Android/darker/PerfEnhance/PerfEnhance.log 2>>/data/media/0/Android/darker/PerfEnhance/PerfEnhance.log &
sleep 60s
while true; do
    [ "$(/data/adb/magisk/busybox ps -ef | grep 'PerfEnhance' | grep -v 'grep')" = "" ] &&  wkdsp "☠️ 服务死掉了喵~。先去看看log, 然后重启再试试或者尝试将selinux关闭后重启或重刷" "1"
    sleep 300s
done