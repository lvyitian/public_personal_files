#!/system/bin/sh
set_perm_recursive "$MODPATH" 0 0 0775 0775
uperf=/data/adb/modules_update/uperf
execute=/data/adb/modules/U-executor_info
tag_mtk="f"
[ "$(getprop ro.hardware)" != "qcom" ] && tag_mtk="t"
remake() {
    killall -9 MTK-Enhance_main 2>/dev/null
    killall -9 uperfEnhance_main 2>/dev/null
    killall -9 PerfEnhance_main 2>/dev/null
    rm -rf /data/media/0/Android/MTK-Enhance*
    rm -rf $uperf/MTK-Enhance_main*
    rm -rf /data/media/0/Android/darker/uperfEnhance
    rm -rf /data/media/0/Android/darker/PerfEnhance
    rm -rf $uperf/bin/PerfEnhance_main
    rm -rf $uperf/bin/uperfEnhance_main
    rm -rf /data/adb/modules*/uperf_enhance*
    rm -rf /data/adb/modules/U-executor_info
}
chk() {
    [ "$tag_mtk" = "t" ] && [ "$(/data/adb/magisk/busybox ps -ef | grep 'uperf' | grep -v 'grep' | grep -v 'Enhance')$(/data/adb/magisk/busybox ps -ef | grep 'cpu_limiter' | grep -v 'grep' | grep -v 'Enhance')" = "" ] && echo "
- 联发科天玑处理器建议搭配uperf或者cpu_Limiter使用，不然会有高温死机的风险！

- 关于uperf, 您可以访问以下链接:
https://github.com/yc9559/uperf

- 关于cpu_Limiter, 您可以访问以下链接:
https://github.com/nakixii/Magisk_CPULimiter"
}
[ "$(getprop ro.hardware | grep exynos)" != "" ] && abort "

- *******************************

- 不支持猎户座处理器

- *******************************
"
[ $KSU ] && abort "

- *******************************

- 不支持KernelSU

- *******************************
"
MODAUTHOR="$(grep_prop author "$MODPATH"/module.prop)" && [ "$MODAUTHOR" != 'world.execute(darker); 酷安@darker_fun_' ] && abort "

- *******************************

- NMSL.

- *******************************
"
remake
echo "
- *******************************"
echo '  ____            __ _____       _'
echo ' |  _ \ ___ _ __ / _| ____|_ __ | |__   __ _ _ __   ___ ___'
echo ' | |_) / _ \ "__| |_|  _| | "_ \| "_ \ / _` | "_ \ / __/ _ \'
echo ' |  __/  __/ |  |  _| |___| | | | | | | (_| | | | | (_|  __/'
echo ' |_|   \___|_|  |_| |_____|_| |_|_| |_|\__,_|_| |_|\___\___|'
echo "
- *******************************

- ℙ𝕖𝕣𝕗𝔼𝕟𝕙𝕒𝕟𝕔𝕖 —— 性能增强模块：解锁核心温度并控制

- 版本: $(grep_prop versionCode "$MODPATH"/module.prop)
- 作者: world.execute(darker); 酷安@darker_fun_
- *******************************
- 有可能导致开机开机卡屏、无限重启、开机完成后经常自动重启等风险- - - - - -
- 甚至可能造成设备损坏等不可逆损失!!- - - - - -
- 需要装好有效救砖模块。- - - - - -
- 或者准备可以有效解密data分区的recovery- - - - - -
- 对造成的损失作者将不负责。- - - - - -
- *******************************"
chk
[ "$tag_mtk" = "t" ] && echo "
- *******************************
- 用户温控检测调整配置文件：
如果你搭配了uperf使用，那么可以在
 /sdcard/Android/darker/PerfEnhance/cfg_enhance.prop 
调整温度检测切换uperf模式的阈值。"
echo "
- 运行log位置: /sdcard/Android/darker/PerfEnhance/PerfEnhance.log

- *******************************
- 正在安装。。。"
mkdir -p $execute
cp $MODPATH/module.prop $execute/module.prop
cp $MODPATH/service.sh $execute/service.sh
cp -r $MODPATH/bin $execute
mkdir -p /data/media/0/Android/darker/PerfEnhance
[ "$tag_mtk" = "t" ] && cp "$MODPATH"/patchfile/cfg_enhance.prop /data/media/0/Android/darker/PerfEnhance/cfg_enhance.prop
rm -rf /data/adb/modules_update/U-executor_info
echo "- Executing me..."
sh $execute/service.sh &
echo "- 安装完成！"
exit 0