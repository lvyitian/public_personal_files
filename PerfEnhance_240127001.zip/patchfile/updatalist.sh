#!/system/bin/sh
uperf="/data/adb/modules/uperf"
execute="/data/adb/modules/U-executor_info"
cp $execute/newver/service.sh $execute/service.sh
cp -r $execute/newver/bin $execute
mkdir -p /data/media/0/Android/darker/PerfEnhance
if [ "$(getprop ro.hardware)" != "qcom" ]; then
    cp $execute/newver/patchfile/cfg_enhance.prop /data/media/0/Android/darker/PerfEnhance
else
    rm -rf /data/media/0/Android/darker/PerfEnhance/cfg_enhance.prop
fi
cp $execute/newver/module.prop $execute/module.prop