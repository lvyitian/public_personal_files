# Reporting Security Issues

If you believe you have found a security vulnerability in swf2js, we encourage you to let us know right away. We will investigate all legitimate reports and do our best to quickly fix the problem.
