package script;

import org.bukkit.*;
import org.bukkit.command.*;
import org.bukkit.plugin.java.*;
import org.mozilla.javascript.*;

import java.io.*;
import java.lang.reflect.*;
import java.nio.charset.*;
import java.util.*;

public class Main extends JavaPlugin {
    public static Main instance;
    public Context context;
    public Scriptable scope;
    public PluginUtil util;
    {
        init();
    }
    public static void loadJsFiles(Context ctx,Scriptable scope, File dir) throws IOException
    {
        if(!dir.isDirectory())
            dir.getAbsoluteFile().mkdirs();
        for(File i : dir.listFiles())
        {
            if(!i.isFile())
            {
                if(i.isDirectory())
                    loadJsFiles(ctx,scope,i);
            } else{
                if(i.getName().toLowerCase(Locale.ENGLISH).endsWith(".js".toLowerCase(Locale.ENGLISH)))
                  loadJsFile(ctx,scope,i);
            }
        }
    }
    public static void loadJsFile(Context ctx,Scriptable scope,File f) throws IOException
    {
        if(f.isFile())
        {
            ctx.evaluateString(scope,readTextFile(f),f.getAbsoluteFile().toString(),1,null);
        }
    }
    public static byte[] readFile(File f) throws IOException
    {
        try(FileInputStream i=new FileInputStream(f))
        {
            byte[] buf=new byte[i.available()];
            i.read(buf);
            return buf;
        }
    }
    public static String readTextFile(File f) throws IOException
    {
        return new String(readFile(f), StandardCharsets.UTF_8);
    }
    public void init()
    {
        instance=this;
        try {
            context=Context.enter();
            context.setOptimizationLevel(-1);
            context.setLanguageVersion(Context.VERSION_ES6);
            scope=context.initStandardObjects();
            ScriptableObject.defineClass(scope, PluginUtil.class);
            util=(PluginUtil) context.newObject(scope,"PluginUtil");
            scope.put("PluginUtil",scope,util);
            loadJsFiles(context,scope,this.getDataFolder());
        }catch(Throwable e){throw new RuntimeException(e);}
    }
    public static Object invokeJsFunction(Function f,Context ctx,Scriptable scope,Object... args)
    {
        return f.call(ctx,f,scope,args);
    }
    public <T> T tryInvokeFunction(String name,Object... args)
    {
        Object f=scope.get(name,scope);
        if(f instanceof Function)
            return (T)invokeJsFunction((Function)f,context,scope,args);
        return null;
    }
    @Override
    public void onLoad()
    {
        tryInvokeFunction("onLoad",false);
    }
    @Override
    public void onDisable()
    {
        tryInvokeFunction("onDisable",false);
    }
    @Override
    public void onEnable()
    {
        tryInvokeFunction("onEnable",false);
    }
    public static <K,V> void removeWhereValueEquals(Map<K,V> m,V value)
    {
        Vector<K> keysToBeRemoved=new Vector<>();
        for(Map.Entry<K,V> e : m.entrySet())
            if(Objects.equals(e.getValue(),value))
                keysToBeRemoved.add(e.getKey());
            for(K k : keysToBeRemoved)
                m.remove(k);
    }
    public void regInternalCmd()
    {
        for(Map.Entry<String,Map<String,Object>> i : this.getDescription().getCommands().entrySet())
        {
            InternalCommandUtil.regCom(this.getName(),InternalCommandUtil.setComAlias(InternalCommandUtil.setComDesc(InternalCommandUtil.setTabCom(InternalCommandUtil.setComPerM(InternalCommandUtil.setComPer(InternalCommandUtil.setComUsa(InternalCommandUtil.newPluginCommand(i.getKey(),this,this),(String)i.getValue().get("usage")),(String)i.getValue().get("permission")),(String)i.getValue().get("permission-message")),this),(String)i.getValue().get("description")),i.getValue().get("aliases")==null?new String[0]:((List<String>)i.getValue().get("aliases")).parallelStream().toArray(String[]::new)));
        }
    }
    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if(command.getName().equalsIgnoreCase(this.getDescription().getCommands().keySet().parallelStream().toArray(String[]::new)[0]))
        {
            tryInvokeFunction("onDisable",true);
            Context.exit();
            System.gc();
            init();
            System.gc();
            try {
            Field cmap= Bukkit.getServer().getClass().getDeclaredField("commandMap");
            cmap.setAccessible(true);
            SimpleCommandMap scmap=(SimpleCommandMap) cmap.get(Bukkit.getServer());
            Field knownCommands=scmap.getClass().getDeclaredField("knownCommands");
            knownCommands.setAccessible(true);
            Map<String,Command> cmds=(Map<String, Command>) knownCommands.get(scmap);
            Command[] tmp=cmds.values().parallelStream().toArray(Command[]::new);
            for(Command i : tmp)
                if(i instanceof PluginCommand)
                    if(Objects.equals(((PluginCommand)i).getPlugin(),this))
                        removeWhereValueEquals(cmds,i);
                    regInternalCmd();
            }catch(Throwable e){throw new RuntimeException(e);}
            System.gc();
            tryInvokeFunction("onLoad",true);
            tryInvokeFunction("onEnable",true);
            sender.sendMessage("["+this.getName()+"]reload complete");
            return true;
        }
        Object b=tryInvokeFunction("onCommand",sender,command,label,args);
        return (b!=null&&!Objects.equals(Undefined.instance,b))?(boolean)b:super.onCommand(sender,command,label,args);
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if(command.getName().equalsIgnoreCase(this.getDescription().getCommands().keySet().parallelStream().toArray(String[]::new)[0]))
            return new ArrayList<>();
        Object b=tryInvokeFunction("onTabComplete",sender, command, alias, args);
        return (b!=null&&!Objects.equals(Undefined.instance,b))?(List<String>)b:super.onTabComplete(sender,command,alias,args);
    }
}
