public class AWA {
    public static void main(String[] args) {

    }
}
