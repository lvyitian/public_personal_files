package mz.lib.minecraft.bukkit;

import mz.lib.TypeUtil;
import mz.lib.fengjian.Fengjian;
import mz.lib.minecraft.bukkit.module.AbsModule;
import mz.lib.minecraft.bukkit.module.IRegistrar;
import mz.lib.minecraft.bukkit.module.RegistrarRegistrar;
import org.bukkit.event.EventHandler;
import org.bukkit.event.server.PluginDisableEvent;

import java.util.stream.Collectors;

public class FengjianBukkit extends AbsModule implements IRegistrar<Class<? extends Fengjian>>
{
	public static FengjianBukkit instance=new FengjianBukkit();
	public FengjianBukkit()
	{
		super(MzLib.instance,RegistrarRegistrar.instance);
	}
	
	@Override
	public Class<Class<? extends Fengjian>> getType()
	{
		return TypeUtil.cast(Class.class);
	}
	
	@Override
	public boolean register(Class<? extends Fengjian> obj)
	{
		if(Fengjian.class.isAssignableFrom(obj))
		{
			Fengjian.install(obj);
			return true;
		}
		return false;
	}
	
	@Override
	public void unregister(Class<? extends Fengjian> obj)
	{
		if(Fengjian.class.isAssignableFrom(obj))
		{
			Fengjian.uninstall(obj);
		}
	}
	
	@EventHandler
	public void onPluginDisable(PluginDisableEvent event)
	{
		//吕易天到此一游 √
		for(Class<? extends Fengjian> f:Fengjian.fengjianMap.keySet().parallelStream().filter(i->i.getClassLoader()==event.getPlugin().getClass().getClassLoader()).collect(Collectors.toList()))
		{
			Fengjian.uninstall(f);
		}
	}
	
	@Override
	public void onDisable()
	{
		Fengjian.uninstallAll();
	}
}
