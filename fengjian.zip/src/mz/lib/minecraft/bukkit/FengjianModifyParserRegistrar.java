package mz.lib.minecraft.bukkit;

import mz.lib.TypeUtil;
import mz.lib.fengjian.IFengjianModifyParser;
import mz.lib.minecraft.bukkit.module.AbsModule;
import mz.lib.minecraft.bukkit.module.IRegistrar;
import mz.lib.minecraft.bukkit.module.RegistrarRegistrar;
import mz.lib.minecraft.bukkit.wrapper.WrappedClassParserRegistrar;

import java.lang.annotation.Annotation;

public class FengjianModifyParserRegistrar<T extends Annotation> extends AbsModule implements IRegistrar<IFengjianModifyParser<T>>
{
	public static FengjianModifyParserRegistrar instance=new FengjianModifyParserRegistrar();
	public FengjianModifyParserRegistrar()
	{
		super(MzLib.instance,RegistrarRegistrar.instance,WrappedClassParserRegistrar.instance,FengjianBukkit.instance);
	}
	
	@Override
	public Class<IFengjianModifyParser<T>> getType()
	{
		return TypeUtil.cast(IFengjianModifyParser.class);
	}
	@Override
	public boolean register(IFengjianModifyParser<T> obj)
	{
		IFengjianModifyParser.parsers.put(obj.getType(),obj);
		return true;
	}
	@Override
	public void unregister(IFengjianModifyParser<T> obj)
	{
		IFengjianModifyParser.parsers.remove(obj.getType(),obj);
	}
	
	@Override
	public void onEnable()
	{
		reg(BukkitFengjianModifyParser.instance);
	}
}
