package mz.lib.minecraft.bukkit;

import mz.lib.fengjian.FengjianModifyPriority;
import mz.lib.fengjian.FengjianModifyType;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.METHOD)
public @interface FengjianBukkitModify
{
	VersionName[] name();
	FengjianModifyType type();
	FengjianModifyPriority priority() default FengjianModifyPriority.NORMAL;
}
