package mz.lib.fengjian;

import mz.lib.TypeUtil;
import mz.lib.wrapper.WrappedObject;

import java.lang.invoke.MethodHandle;
import java.util.Optional;
import java.util.function.BiFunction;

public class ProcessedModify<T extends Fengjian> implements BiFunction<Object[],Object,Object>
{
	public Class<? extends WrappedObject>[] wrappers;
	public Class<? extends WrappedObject> retWrapper;
	public MethodHandle handle;
	public ProcessedModify(Class<? extends WrappedObject>[] wrappers,Class<? extends WrappedObject> retWrapper,MethodHandle handle)
	{
		this.wrappers=wrappers;
		this.retWrapper=retWrapper;
		this.handle=handle;
	}
	
	@Override
	public Object apply(Object[] objects,Object extra)
	{
		boolean isStatic=objects[0]==null;
		Object[] args=new Object[(isStatic?-1:0)+objects.length];
		try
		{
			for(int i=0;i<args.length;i++)
			{
				args[i]=wrappers[i+(isStatic?1:0)]==null?objects[i+(isStatic?1:0)]:WrappedObject.wrap(wrappers[i+(isStatic?1:0)],objects[i+(isStatic?1:0)]);
			}
			Object r=handle.invokeWithArguments(args);
			for(int i=0;i<args.length;i++)
			{
				if(wrappers[i+(isStatic?1:0)]!=null)
				{
					objects[i+(isStatic?1:0)]=((WrappedObject)args[i]).getRaw();
				}
			}
			if(retWrapper!=null)
			{
				if(r instanceof Optional)
				{
					r=((Optional<?>)r).orElse(null);
					if(r!=null)
						r=((WrappedObject)r).getRaw();
					r=Optional.ofNullable(r);
				}
				else
				{
					if(r!=null)
						r=((WrappedObject)r).getRaw();
				}
			}
			return r;
		}
		catch(Throwable e)
		{
			throw TypeUtil.throwException(e);
		}
	}
}
