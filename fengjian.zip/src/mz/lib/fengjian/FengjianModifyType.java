package mz.lib.fengjian;

public enum FengjianModifyType
{
	/**
	 * Inject before the original method
	 */
	INJECT_BEFORE,
	/**
	 * Overwrite the method or constructor
	 */
	OVERWRITE,
	/**
	 * Inject code before returning (excluding situations when exceptions were thrown)
	 */
	INJECT_AFTER,
	/**
	 * Inject code into exception handler table and catch all Throwable objects
	 */
	INJECT_CATCH
}
