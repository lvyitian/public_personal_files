package mz.lib.fengjian;

import mz.lib.MethodInfo;

import java.util.function.BiFunction;

public class FengjianPoint
{
	MethodInfo target;
	FengjianModifyType type;
	FengjianModifyPriority priority;
	BiFunction<Object[],Object,Object> code;
	
	public FengjianPoint(MethodInfo target,FengjianModifyType type,FengjianModifyPriority priority,BiFunction<Object[],Object,Object> code)
	{
		this.target=target;
		this.type=type;
		this.priority=priority;
		this.code=code;
	}
}
