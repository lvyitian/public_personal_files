package mz.lib.fengjian;

import java.util.List;
import java.util.function.BiFunction;

public abstract class FengjianData
{
	public static List<List<List<List<BiFunction<Object[],Object,Object>>>>> store;
}
