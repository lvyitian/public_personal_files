package mz.lib.fengjian;

public enum FengjianModifyPriority
{
	LOWEST,
	LOW,
	NORMAL,
	HIGH,
	HIGHEST
}
