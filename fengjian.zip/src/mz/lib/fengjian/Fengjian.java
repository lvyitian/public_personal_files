package mz.lib.fengjian;

import mz.javassist.*;
import mz.javassist.compiler.CompileError;
import mz.lib.*;
import mz.lib.wrapper.WrappedObject;
import net.bytebuddy.agent.ByteBuddyAgent;

import javax.tools.ToolProvider;
import java.io.ByteArrayInputStream;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.CopyOnWriteArraySet;
import java.util.function.BiFunction;

public interface Fengjian
{
	static Map<Class,byte[]> rawClassesData=new ConcurrentHashMap<>();
	static Map<MethodInfo,Integer> idMap=new ConcurrentHashMap<>();
	static Map<Class<? extends Fengjian>,List<FengjianPoint>> fengjianMap=new ConcurrentHashMap<>();
	static IncrementalIdMap<List<List<List<BiFunction<Object[],Object,Object>>>>> fengjians=new IncrementalIdMap<>(new CopyOnWriteArrayList<>(),new CopyOnWriteArraySet<>());
	
	static void init()
	{
		try
		{
			ByteBuddyAgent.install();
			ClassUtil.getAgentInstrumentation();
		}
		catch(Throwable e)
		{
			System.err.println("MzLib不支持在Docker容器中运行");
			if(ToolProvider.getSystemJavaCompiler()==null)
				System.err.println("无法注入JavaAgent，请使用JDK");
			else
				System.err.println("无法注入JavaAgent，请添加启动参数-XX:+StartAttachListener并删除-XX:+DisableAttachMechanism和-Djdk.attach.allowAttachSelf=false");
			throw TypeUtil.throwException(e);
		}
		if(TypeUtil.hasThrowable(()->Class.forName("mz.lib.fengjian.FengjianData",false,ClassUtil.extClassLoader)))
		{
			ClassUtil.loadClass("mz.lib.fengjian.FengjianData",FileUtil.readInputStream(Fengjian.class.getClassLoader().getResourceAsStream("mz/lib/fengjian/FengjianData.class")),ClassUtil.extClassLoader);
			ClassUtil.loadClass("mz.lib.Ref",FileUtil.readInputStream(Fengjian.class.getClassLoader().getResourceAsStream("mz/lib/Ref.class")),ClassUtil.extClassLoader);
		}
		
		rawClassesData.clear();
		idMap.clear();
		fengjianMap.clear();
		fengjians.clear();
		FengjianData.store=fengjians.store;
	}
	
	static void uninstallAll()
	{
		for(Map.Entry<Class,byte[]> e:rawClassesData.entrySet())
		{
			ClassUtil.loadClass(e.getKey().getName(),e.getValue(),e.getKey().getClassLoader());
		}
	}
	
	static void uninstall(FengjianPoint point)
	{
		fengjians.get(idMap.get(point.target)).get(point.type.ordinal()).get(point.priority.ordinal()).remove(point.code);
	}
	static void uninstall(Class<? extends Fengjian> fengjian)
	{
		for(FengjianPoint p:fengjianMap.get(fengjian))
		{
			uninstall(p);
		}
		fengjianMap.remove(fengjian);
	}
	
	static void install(Class<? extends Fengjian> fengjian)
	{
		try
		{
			Class<?> rawClass=WrappedObject.getRawClass(TypeUtil.cast(fengjian));
			if(rawClass==null)
				throw new NullPointerException();
			if(!rawClassesData.containsKey(rawClass))
			{
				ClassPool cp=new ClassPool(rawClass.getClassLoader());
				CtClass ct=cp.get(rawClass);
				rawClassesData.put(rawClass,ct.toBytecode());
				ct=cp.makeClass(new ByteArrayInputStream(ct.toBytecode()));
				CtMember.Cache cms=((CtClassType) ct).getMembers();
				CtMember it=cms.methodHead();
				while(it!=cms.lastCons())
				{
					it=it.next();
					
					if(Modifier.isAbstract(((CtBehavior)it).getModifiers()))
						continue;
					
					List<List<List<BiFunction<Object[],Object,Object>>>> list=new CopyOnWriteArrayList<>();
					for(int i=0;i<FengjianModifyType.values().length;i++)
					{
						List<List<BiFunction<Object[],Object,Object>>> l=new CopyOnWriteArrayList<>();
						for(int j=0;j<FengjianModifyPriority.values().length;j++)
						{
							l.add(new CopyOnWriteArrayList<>());
						}
						list.add(l);
					}
					
					int id=fengjians.alloc(list);
					idMap.put(new MethodInfo(rawClass.getClassLoader(),it),id);
					
					String thiz=Modifier.isStatic(it.getModifiers())?"null":"$0";
					Class<?> retType=void.class;
					if(it instanceof CtMethod)
						retType=ClassUtil.getClass(rawClass.getClassLoader(),((CtMethod)it).getReturnType());
					Class<?>[] argTypes=ClassUtil.getClasses(rawClass.getClassLoader(),((CtBehavior) it).getParameterTypes());
					String argObjects=TypeUtil.codeArgObjects(argTypes);
					
					StringBuilder code;
					if(it instanceof CtMethod)
					{
						code=new StringBuilder("{");
						code.append("   Object[] args=new Object[]{"+thiz+(argObjects.length()==0 ? "" : ","+argObjects)+"};");
						code.append("   java.util.Iterator i=((java.util.List)((java.util.List)mz.lib.fengjian.FengjianData.store.get("+id+")).get("+FengjianModifyType.INJECT_BEFORE.ordinal()+")).iterator();");
						code.append("   while(i.hasNext())");
						code.append("   {");
						code.append("       java.util.Iterator j=((java.util.List)i.next()).iterator();");
						code.append("       while(j.hasNext())");
						code.append("       {");
						code.append("           java.util.Optional r=(java.util.Optional)((java.util.function.BiFunction)j.next()).apply(args,null);");
						code.append("           if(r!=null)");
						code.append("           {");
						if(retType!=void.class)
							code.append("           return "+TypeUtil.codeCast(retType,"r.orElse(null)",Object.class)+";");
						else
							code.append("           return;");
						code.append("           }");
						code.append("       }");
						code.append("   }");
						//Overwrite
						code.append("   i=((java.util.List)((java.util.List)mz.lib.fengjian.FengjianData.store.get("+id+")).get("+FengjianModifyType.OVERWRITE.ordinal()+")).iterator();");
						code.append("   while(i.hasNext())");
						code.append("   {");
						code.append("       java.util.Iterator j=((java.util.List)i.next()).iterator();");
						code.append("       while(j.hasNext())");
						code.append("       {");
						String t="((java.util.function.BiFunction)j.next()).apply(args,null)";
						if(retType==void.class)
							code.append(t+";return;");
						else
							code.append("return "+TypeUtil.codeCast(retType,t,Object.class)+";");
						code.append("       }");
						code.append("   }");
						for(int i=0;i<argTypes.length;i++)
							code.append("$"+(i+1)+"="+TypeUtil.codeCast(argTypes[i],"args["+(i+1)+"]",Object.class)+";");
						code.append('}');
						((CtMethod) it).insertBefore(code.toString());
					}
					
					code=new StringBuilder("{");
					code.append("   Object[] args=new Object[]{"+thiz+(argObjects.length()==0?"":(","+argObjects))+"};");
					code.append("   mz.lib.Ref lr=new mz.lib.Ref("+TypeUtil.codeCast(Object.class,"$_",retType)+");");
					code.append("   java.util.Iterator i=((java.util.List)((java.util.List)mz.lib.fengjian.FengjianData.store.get("+id+")).get("+FengjianModifyType.INJECT_AFTER.ordinal()+")).iterator();");
					code.append("   while(i.hasNext())");
					code.append("   {");
					code.append("       java.util.Iterator j=((java.util.List)i.next()).iterator();");
					code.append("       while(j.hasNext())");
					code.append("       {");
					code.append("           java.util.Optional r=(java.util.Optional)((java.util.function.BiFunction)j.next()).apply(args,lr);");
					code.append("           if(r!=null)");
					code.append("           {");
					code.append("               return "+TypeUtil.codeCast(retType,"r.orElse(null)",Object.class)+";");
					code.append("           }");
					code.append("       }");
					code.append("   }");
					if(retType!=void.class)
						code.append("   $_="+TypeUtil.codeCast(retType,"lr.get()",Object.class)+";");
					code.append('}');
					((CtBehavior) it).insertAfter(code.toString());
					
					if(it instanceof CtMethod)
					{
						code=new StringBuilder("{");
						code.append("   Object[] args=new Object[]{"+thiz+(argObjects.length()==0 ? "" : ","+argObjects)+"};");
						code.append("   java.util.Iterator i=((java.util.List)((java.util.List)mz.lib.fengjian.FengjianData.store.get("+id+")).get("+FengjianModifyType.INJECT_CATCH.ordinal()+")).iterator();");
						code.append("   while(i.hasNext())");
						code.append("   {");
						code.append("       java.util.Iterator j=((java.util.List)i.next()).iterator();");
						code.append("       while(j.hasNext())");
						code.append("       {");
						code.append("           java.util.Optional r=(java.util.Optional)((java.util.function.BiFunction)j.next()).apply(args,$e);");
						code.append("           if(r!=null)");
						code.append("           {");
						code.append("               return "+TypeUtil.codeCast(retType,"r.orElse(null)",Object.class)+";");
						code.append("           }");
						code.append("       }");
						code.append("   }");
						code.append("   throw $e;");
						code.append('}');
						((CtBehavior) it).addCatch(code.toString(),cp.get(Throwable.class),"$e");
					}
				}
//				try(FileOutputStream fos=new FileOutputStream(new File("awa.class")))
//				{
//					fos.write(ct.toBytecode());
//				}
				ClassUtil.loadClass(ct.getName(),ct.toBytecode(),rawClass.getClassLoader());
			}
			List<FengjianPoint> points=new ArrayList<>();
			for(Method m:fengjian.getDeclaredMethods())
			{
				points.addAll(IFengjianModifyParser.applyAll(rawClass,m));
			}
			for(FengjianPoint p:points)
			{
				fengjians.get(idMap.get(p.target)).get(p.type.ordinal()).get(p.priority.ordinal()).add(p.code);
			}
			fengjianMap.put(fengjian,points);
			TypeUtil.<CompileError>fakeThrow();
		}
		catch(Throwable e)
		{
			throw TypeUtil.throwException(e);
		}
	}
}
