package mz.lib.fengjian;

import com.google.common.collect.Lists;
import io.github.karlatemp.unsafeaccessor.Root;
import mz.lib.ListUtil;
import mz.lib.MapEntry;
import mz.lib.MethodInfo;
import mz.lib.TypeUtil;
import mz.lib.Optional;
import mz.lib.wrapper.WrappedObject;

import java.lang.annotation.Annotation;
import java.lang.reflect.Executable;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public interface IFengjianModifyParser<T extends Annotation>
{
	Class<T> getType();
	default FengjianPoint apply(Class rawClass,Method modify)
	{
		T ann=modify.getDeclaredAnnotation(getType());
		if(ann==null)
			return null;
		return apply(rawClass,modify,ann);
	}
	FengjianPoint apply(Class rawClass,Method modify,T annotation);
	
	static List<FengjianPoint> applyAll(Class rawClass,Method modify)
	{
		List<FengjianPoint> r=new ArrayList<>();
		for(IFengjianModifyParser parser:parsers.values())
		{
			FengjianPoint point=parser.apply(rawClass,modify);
			if(point!=null)
				r.add(point);
		}
		return r;
	}
	
	static Map<Class<? extends Annotation>,IFengjianModifyParser> parsers=ListUtil.toMap(Lists.newArrayList(new MapEntry<>(FengjianModify.class,new IFengjianModifyParser<FengjianModify>()
	{
		public Class<FengjianModify> getType()
		{
			return FengjianModify.class;
		}
		public FengjianPoint apply(Class rawClass,Method modify,FengjianModify annotation)
		{
			Class<? extends WrappedObject>[] wrappers=new Class[modify.getParameterCount()+1];
			wrappers[0]=(Class<? extends WrappedObject>) modify.getDeclaringClass();
			List<Class<?>> rawArgTypes=new ArrayList<>();
			Class<?>[] pts=modify.getParameterTypes();
			Class<?> retType=modify.getReturnType();
			for(int i=0;i<pts.length;i++)
			{
				if(WrappedObject.class.isAssignableFrom(pts[i]))
				{
					wrappers[i+1]=TypeUtil.cast(pts[i]);
					rawArgTypes.add(WrappedObject.getRawClass(wrappers[i+1]));
				}
				else
					rawArgTypes.add(pts[i]);
			}
			Executable target=null;
			for(String n: annotation.name())
			{
				try
				{
					if(n.equals("<init>"))
						target=rawClass.getDeclaredConstructor(rawArgTypes.toArray(new Class[0]));
					else
						target=rawClass.getDeclaredMethod(n,rawArgTypes.toArray(new Class[0]));
				}
				catch(NoSuchMethodException e)
				{
				}
			}
			if(target==null)
			{
				if(modify.isAnnotationPresent(Optional.class))
					return null;
				else
					throw TypeUtil.throwException(new NoSuchMethodException("fengjian target of "+modify));
			}
			try
			{
				return new FengjianPoint(new MethodInfo(target),annotation.type(),annotation.priority(),new ProcessedModify<>(wrappers,WrappedObject.class.isAssignableFrom(retType) ? TypeUtil.cast(retType) : null,Root.getTrusted().unreflect(modify)));
			}
			catch(Throwable e)
			{
				throw TypeUtil.throwException(e);
			}
		}
	})));
}
