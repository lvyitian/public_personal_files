#!/bin/sh
chattr -R -i /data/vendor/thermal
rm -rf  /data/vendor/thermal/config/*