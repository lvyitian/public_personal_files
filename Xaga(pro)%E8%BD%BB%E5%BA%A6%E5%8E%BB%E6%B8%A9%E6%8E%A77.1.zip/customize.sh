#!/bin/sh
SKIPUNZIP=0
BASEDIR="$(dirname $(readlink -f "$0"))"

rubbish(){
del="/data/system/package_cache/*
/cache/dalvik-cache/*
/data/dalvik-cache/arm/*
/data/dalvik-cache/arm64/*"
for i in $del; do
    rm -rf $i
done
}

SutoLiu_nmsl(){
    #delete conflict modules
    MODS_PATH="/data/adb/modules"
    s="Sut"
    b="oLiu"
    for i in $(ls $MODS_PATH); do
        if [[ ! -z $(grep author=$s$b $MODS_PATH/$i/module.prop) ]]; then
            echo wow，you installed sutoliu modules
            chattr -R -i $MODS_PATH/$i
            rm -rf $MODS_PATH/$i
        fi
    done
}

use_MIUI_CloudCtrl_interface(){
    chattr -R -i /data/vendor/thermal
    rm -rf /data/vendor/thermal/config/*
    cp -rf $update_PATH/SlightThermal/thermal/* /data/vendor/thermal/config
    chmod 666 /data/vendor/thermal/config/*
    chattr +i /data/vendor/thermal/config
    echo "Already locked /data/vendor/thermal/config"
    echo "prevent cloud control"
    echo "Uninstall module to recover"
}

Adapt_Pandora_install(){
    #Adapt Pandora beta6,7 kennel
    Pandora_PATH="$MODS_PATH/pandora_kernel"
    update_PATH="/data/adb/modules_update"
    if [[ -e $Pandora_PATH ]]; then
        for i in 6 7; do
            if [[ ! -z $(grep version=v$i $Pandora_PATH/module.prop) ]]; then
                rm -r $Pandora_PATH/system/vendor/bin
                mv $update_PATH/SlightThermal/PandoraV$i.sh $Pandora_PATH/service.sh
            fi
        done
    fi
    rm -rf $update_PATH/SlightThermal/Pandora*.sh
    wk="/sys/class/thermal/thermal_message/enable"
    #mode="/data/vendor/thermal/thermal-global-mode"
    #echo 0 > $mode
    if  [  -e $wk  ]; then
        echo 1 > $wk
    fi
}

install_final(){
    echo
    echo "$MODNAME install finished"
}
rubbish
SutoLiu_nmsl
#Adapt_Pandora_install
use_MIUI_CloudCtrl_interface
install_final

