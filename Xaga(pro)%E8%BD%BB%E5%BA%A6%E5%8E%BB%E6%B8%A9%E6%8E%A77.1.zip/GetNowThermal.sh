#!/bin/sh
BASEDIR="$(dirname $(readlink -f "$0"))"
echo "now time：$(date "+%Y-%m-%d %H:%M:%S")" > $BASEDIR/NowUsedThermal.conf
cat /data/vendor/thermal/decrypt.txt >> $BASEDIR/NowUsedThermal.conf