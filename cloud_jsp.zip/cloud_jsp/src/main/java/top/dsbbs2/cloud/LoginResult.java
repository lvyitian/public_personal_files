package top.dsbbs2.cloud;

import com.google.gson.GsonBuilder;

public class LoginResult {
  public final long code;
  public final String message;
  public LoginResult(long code,String message) {
	  this.code=code;
	  this.message=message;
  }
  @SuppressWarnings("deprecation")
  @Override
  public String toString() {
	  return new GsonBuilder().enableComplexMapKeySerialization().setLenient().create().toJson(this);
  }
}
