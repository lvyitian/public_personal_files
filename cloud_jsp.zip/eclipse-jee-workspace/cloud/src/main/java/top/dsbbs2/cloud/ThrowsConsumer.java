package top.dsbbs2.cloud;

import java.util.function.Consumer;

@FunctionalInterface
public interface ThrowsConsumer<T> extends Consumer<T> {
    void accept0(T obj) throws Throwable;
    @Override
    default void accept(T obj) {
    	try {
    	this.accept0(obj);
    	}catch(Throwable t) {
    		throw new RuntimeException(t);
    	}
    }
    static <T> ThrowsConsumer<T> of(ThrowsConsumer<T> t){return t;}
}
