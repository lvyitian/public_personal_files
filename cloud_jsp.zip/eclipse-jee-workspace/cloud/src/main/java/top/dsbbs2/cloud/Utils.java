package top.dsbbs2.cloud;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.nio.charset.StandardCharsets;
import java.security.SecureRandom;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.LongStream;

public class Utils {
	/**
	 * 获得随机字符串
	 * @param len             需要的长度
	 * @param special        是否需要特殊符号
	 * @return String       返回随机字符串
	 */
	public static String getRandomStr(long len,boolean special) {
		List<Character> chars=Arrays.asList(new Character[] {  'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k',
		        'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v',
		        'w', 'x', 'y', 'z', 'A', 'B', 'C', 'D', 'E', 'F', 'G',
		        'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R',
		        'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z', '0', '1', '2',
		        '3', '4', '5', '6', '7', '8', '9'}).parallelStream().collect(Collectors.toList());
		if(special) chars.addAll(Arrays.asList(new Character[] {'!', '@', '#', '$', '?', '|', '{', '/', ':', ';',
	            '%', '^', '&', '*', '(', ')', '-', '_', '[', ']',
	            '}', '<', '>', '~', '+', '=', ',', '.'}));
		Collections.shuffle(chars);
		StringBuffer res=new StringBuffer();
		SecureRandom rand=new SecureRandom();
		LongStream.range(0,len).parallel().forEach(i->res.append(chars.get(rand.nextInt(chars.size()))));
		return res.toString();
	}
	public static String getRandomStr(long len) {
		return getRandomStr(len,true);
	}
	public static String throwableToString(Throwable t) {
		try(ByteArrayOutputStream baos=new ByteArrayOutputStream()){
			try(PrintStream s=new PrintStream(baos,true,StandardCharsets.UTF_8)){
				t.printStackTrace(s);
				return new String(baos.toByteArray(),StandardCharsets.UTF_8);
			}
		}catch(Throwable t2) {
			t2.addSuppressed(t);
			throw new RuntimeException(t2);
		}
	}
	public static Optional<Throwable> sendMail(String address,String title,String content) {
		// TODO: implement email sending
		System.out.println(content);
		try {
		return Optional.ofNullable(new Throwable("邮件发送失败!"));
		}catch(Throwable t) {
			return Optional.ofNullable(t);
		}
	}
	public static boolean literallyTrue() {return true;}
}
