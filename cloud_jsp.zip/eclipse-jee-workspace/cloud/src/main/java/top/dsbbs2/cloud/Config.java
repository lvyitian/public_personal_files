package top.dsbbs2.cloud;

public class Config {
	public static final String HOST="127.0.0.1";
	public static final int PORT=3306;
	public static final String USER="root";
	public static final String PASSWORD="123123lyt";
	public static final String DATABASE="cloud";
	public static final String PREFIX="userdata";
}
