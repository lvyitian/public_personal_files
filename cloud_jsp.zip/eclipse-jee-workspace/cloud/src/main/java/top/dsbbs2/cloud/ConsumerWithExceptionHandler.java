package top.dsbbs2.cloud;

import java.util.function.Consumer;

@FunctionalInterface
public interface ConsumerWithExceptionHandler<T> extends ThrowsConsumer<T> {
    @Override
    default void accept(T obj) {
    	try {
    	this.accept0(obj);
    	}catch(Throwable t) {
    		this.handleException(t);
    	}
    }
    default void handleException(Throwable t) {}
    static <T> ConsumerWithExceptionHandler<T> of(ConsumerWithExceptionHandler<T> t){return t;}
    static <T> ConsumerWithExceptionHandler<T> of(ThrowsConsumer<T> t,Consumer<Throwable> handler){
    	return new ConsumerWithExceptionHandler<T>() {
    		@Override
    		public void accept0(T obj) throws Throwable {
    			t.accept0(obj);
    		}
    		@Override
    		public void handleException(Throwable t) {handler.accept(t);}
    	};
    }
}
