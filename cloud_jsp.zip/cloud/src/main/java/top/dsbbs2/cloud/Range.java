package top.dsbbs2.cloud;


// Index starts from 0 and both start and end are inclusive
public class Range {
    public long start,end;
    public Range(long start,long end) {this.start=start;this.end=end;}
    public long length() {
    	return Math.max(0, end-start+1);
    }
}
