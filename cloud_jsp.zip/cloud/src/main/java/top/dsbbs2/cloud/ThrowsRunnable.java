package top.dsbbs2.cloud;

@FunctionalInterface
public interface ThrowsRunnable extends Runnable {
  void run0() throws Throwable;
  @Override
  default void run() {
	  try {
		this.run0();  
	  }catch(Throwable t) {throw new RuntimeException(t);}
  }
  static ThrowsRunnable of(ThrowsRunnable t) {return t;}
}
