package top.dsbbs2.cloud;

import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;

public class MyScheduler {
    public static final ConcurrentHashMap<Runnable,Optional<Void>> tasks=new ConcurrentHashMap<>();
    public static void submitAndWait(Runnable r) {
    	boolean[] done= {false};
    	Throwable[] exc= {null};
    	tasks.put(()->{
    		try {
    			r.run();
    		}catch(Throwable t){exc[0]=t;}finally {
    			done[0]=true;
    		}
    	}, Optional.empty());
    	while(!done[0]) {
    		try {
    			Thread.sleep(1);
    		}catch(Throwable t) {throw new RuntimeException(t);}
    	}
    	Optional.ofNullable(exc[0]).map(RuntimeException::new).ifPresent(i->{throw i;});
    }
    static {
    	new Thread(()->{
    		while(true) {
    			if(!tasks.isEmpty()) {
    				synchronized(MyFileCleaner.safepoint) {
    					tasks.keySet().parallelStream().forEach(i->{tasks.remove(i);try{i.run();}catch(Throwable t) {t.printStackTrace();}});
    				}
    			}
    			try {
    				Thread.sleep(1);
    			}catch(Throwable t) {throw new RuntimeException(t);}
    		}
    	}) {{this.setDaemon(true);this.setName("MyScheduler EventLoop Thread");}}.start();
    }
}
