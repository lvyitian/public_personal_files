package top.dsbbs2.cloud;

import java.io.File;
import java.lang.ref.PhantomReference;
import java.lang.ref.Reference;
import java.lang.ref.ReferenceQueue;
import java.util.concurrent.CopyOnWriteArraySet;
import java.util.stream.Stream;

import org.apache.tomcat.util.http.fileupload.FileItem;
import org.apache.tomcat.util.http.fileupload.disk.DiskFileItemFactory;

public class MyFileCleaner {
	public static final Object safepoint=new Object();
	public static final File tempDir=new File(System.getProperty("user.dir"),"file_upload_temp").getAbsoluteFile();
	public static final ReferenceQueue<DiskFileItemFactory> pendingCleanupQueue=new ReferenceQueue<>();
	public static final CopyOnWriteArraySet<PhantomReference<DiskFileItemFactory>> registeredPhantomReferences=new CopyOnWriteArraySet<>();
	public static final ReferenceQueue<FileItem> pendingFileItemsCleanupQueue=new ReferenceQueue<>();
	public static final CopyOnWriteArraySet<PhantomReference<FileItem>> registeredFileItemPhantomReferences=new CopyOnWriteArraySet<>();
	public static DiskFileItemFactory register(DiskFileItemFactory f) {
    	registeredPhantomReferences.add(new PhantomReference<>(f,pendingCleanupQueue));
    	return f;
    }
	public static FileItem register(FileItem f) {
		registeredFileItemPhantomReferences.add(new PhantomReference<FileItem>(f, pendingFileItemsCleanupQueue));
		return f;
	}
    static {
    	new Thread(()->{
    		while(true) {
    			try {
    			Reference<? extends DiskFileItemFactory> i=pendingCleanupQueue.poll();
    			if(i!=null) {
    				registeredPhantomReferences.remove(i);
    				synchronized(safepoint) {
    				Stream.of(tempDir.listFiles()).filter(File::isFile).forEach(ConsumerWithExceptionHandler.of(f->{f.deleteOnExit();f.delete();}));
    				}
    			}
    			Thread.sleep(1);
    			}catch(Throwable t) {t.printStackTrace();}
    		}
    	}) {{this.setDaemon(true);this.setName("File Cleanup Thread");}}.start();
    	new Thread(()->{
    		while(true) {
    			try {
    			Reference<? extends FileItem> i=pendingFileItemsCleanupQueue.poll();
    			if(i!=null) {
    				registeredFileItemPhantomReferences.remove(i);
    				synchronized(safepoint) {
    				Stream.of(tempDir.listFiles()).filter(File::isFile).forEach(ConsumerWithExceptionHandler.of(f->{f.deleteOnExit();f.delete();}));
    				}
    			}
    			Thread.sleep(1);
    			}catch(Throwable t) {t.printStackTrace();}
    		}
    	}) {{this.setDaemon(true);this.setName("FileItem Cleanup Thread");}}.start();
    }
}
