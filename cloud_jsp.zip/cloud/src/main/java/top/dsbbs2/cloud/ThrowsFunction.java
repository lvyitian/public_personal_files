package top.dsbbs2.cloud;

import java.util.function.Function;

@FunctionalInterface
public interface ThrowsFunction<T,R> extends Function<T,R> {
    R apply0(T obj) throws Throwable;
    @Override
    default R apply(T obj) {
    	try {
    	return this.apply0(obj);
    	}catch(Throwable t) {
    		throw new RuntimeException(t);
    	}
    }
    static <T,R> ThrowsFunction<T,R> of(ThrowsFunction<T,R> t){return t;}
}
