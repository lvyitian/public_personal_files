#!/system/bin/sh
MODDIR=${0%/*}
. ${MODDIR}/util_func.sh
disable_all_modules
disable_modules_in_list
