#!/system/bin/sh

rm -rf /sdcard/Android/ct

exit 0